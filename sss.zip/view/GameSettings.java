package com.Knight.view;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Input;
import com.badlogic.gdx.audio.Music;
import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.GL20; // Import GL20 for blending

public class GameSettings {
    // تنظیمات صدا
    public static float musicVolume = 1f;
    public static float sfxVolume = 0.5f;
    public static boolean musicEnabled = true;
    public static boolean sfxEnabled = true;
    public static Music backgroundMusic;

    public static float brightness = 1.0f;


    public static String language = "English";

    public static int keyMoveLeft = Input.Keys.LEFT;
    public static int keyMoveRight = Input.Keys.RIGHT;
    public static int keyJump = Input.Keys.SPACE;
    public static int keyDash = Input.Keys.SHIFT_LEFT;
    public static int keyNail = Input.Keys.X;


    public static String getKeyName(int keyCode) {
        return Input.Keys.toString(keyCode);
    }


    public static String getPersianKeyName(int keyCode) {
        switch (keyCode) {
            case Input.Keys.LEFT: return "چپ";
            case Input.Keys.RIGHT: return "راست";
            case Input.Keys.SPACE: return "پرش";
            case Input.Keys.SHIFT_LEFT: return "دش";
            case Input.Keys.X: return "حمله";
            // میتونی موارد بیشتری اضافه کنی
            default: return Input.Keys.toString(keyCode);
        }
    }

    // اعمال کلی تنظیمات (صدا و پخش موزیک)
    public static void applySettings() {
        if (backgroundMusic != null) {
            backgroundMusic.setVolume(musicEnabled ? musicVolume : 0f);
            if (musicEnabled && !backgroundMusic.isPlaying()) {
                backgroundMusic.play();
            } else if (!musicEnabled) {
                backgroundMusic.pause();
            }
        }
    }


    public static void applyMusicVolume() {
        applySettings(); }


    public static void applyBrightness() {

    }


    public static void resetKeys() {
        keyMoveLeft = Input.Keys.LEFT;
        keyMoveRight = Input.Keys.RIGHT;
        keyJump = Input.Keys.SPACE;
        keyDash = Input.Keys.SHIFT_LEFT;
        keyNail = Input.Keys.X;
    }
}
