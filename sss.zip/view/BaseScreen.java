package com.Knight.view;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Screen;
import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.GL20;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.Pixmap;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.scenes.scene2d.Stage;
import com.badlogic.gdx.scenes.scene2d.ui.Skin;
import com.badlogic.gdx.utils.viewport.FitViewport;

public abstract class BaseScreen implements Screen {

    protected Stage stage;
    protected Skin skin;
    protected Texture backgroundTexture;
    protected SpriteBatch batch;
    protected Texture overlayTexture;

    @Override
    public void show() {
        if (stage == null) {
            stage = new Stage(new FitViewport(1280, 720));
        }

        if (skin == null) {
            skin = new Skin(Gdx.files.internal("ui/uiskin.json"));
        }

        if (batch == null) {
            batch = new SpriteBatch();
        }

        if (overlayTexture == null) {
            Pixmap pixmap = new Pixmap(1, 1, Pixmap.Format.RGBA8888);
            pixmap.setColor(Color.WHITE);
            pixmap.fill();
            overlayTexture = new Texture(pixmap);
            pixmap.dispose();
        }
    }

    @Override
    public void render(float delta) {
        Gdx.gl.glClearColor(0, 0, 0, 1);
        Gdx.gl.glClear(GL20.GL_COLOR_BUFFER_BIT);

        if (backgroundTexture != null) {
            batch.begin();
            batch.setColor(Color.WHITE);
            batch.draw(backgroundTexture, 0, 0, 1280, 720);
            batch.end();
        }

        if (stage != null) {
            stage.act(delta);
            stage.draw();
        }

        drawBrightnessOverlay();
    }

    protected void drawBrightnessOverlay() {
        if (GameSettings.brightness < 1.0f) {
            float alpha = 1.0f - GameSettings.brightness;

            Gdx.gl.glEnable(GL20.GL_BLEND);
            Gdx.gl.glBlendFunc(GL20.GL_SRC_ALPHA, GL20.GL_ONE_MINUS_SRC_ALPHA);

            batch.begin();
            batch.setColor(0, 0, 0, alpha);
            batch.draw(overlayTexture, 0, 0, 1280, 720);
            batch.setColor(Color.WHITE);
            batch.end();

            Gdx.gl.glDisable(GL20.GL_BLEND);
        }
    }

    @Override
    public void resize(int width, int height) {
        if (stage != null) {
            stage.getViewport().update(width, height, true);
        }
    }

    @Override
    public void pause() {}

    @Override
    public void resume() {}

    @Override
    public void hide() {}

    @Override
    public void dispose() {
        if (stage != null) stage.dispose();
        if (skin != null) skin.dispose();
        if (backgroundTexture != null) backgroundTexture.dispose();
        if (batch != null) batch.dispose();
        if (overlayTexture != null) overlayTexture.dispose();
    }
}
