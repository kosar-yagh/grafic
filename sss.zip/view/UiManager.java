package com.Knight.view;

import com.Knight.Mainn;
import com.badlogic.gdx.Screen;

public class UiManager {
    private static Mainn main;
    public static void init(Mainn main){
        UiManager.main=main;
    }
    public static void setScreen(Screen screen){
        main.setScreen(screen);
    }
}
