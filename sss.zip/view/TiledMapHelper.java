package com.Knight.view;

import com.Knight.model.SolidBlock;
import com.badlogic.gdx.maps.MapLayer;
import com.badlogic.gdx.maps.MapObject;
import com.badlogic.gdx.maps.objects.RectangleMapObject;
import com.badlogic.gdx.maps.tiled.TiledMap;
import com.badlogic.gdx.maps.tiled.TmxMapLoader;
import com.badlogic.gdx.math.Rectangle;
import com.badlogic.gdx.utils.Array;

public class TiledMapHelper {
    private TiledMap tiledMap;

    public TiledMap loadMap(String path) {
        tiledMap = new TmxMapLoader().load(path);

        // 🔥 این کد تمام لایه‌های مپ شما را در کنسول چاپ می‌کند تا اسم دقیقشان را چک کنی
        System.out.println("--- ALL AVAILABLE LAYERS IN YOUR MAP ---");
        for (MapLayer layer : tiledMap.getLayers()) {
            System.out.println("-> Layer Name Found: '" + layer.getName() + "'");
        }
        System.out.println("----------------------------------------");

        return tiledMap;
    }

    public Array<SolidBlock> getBlocksFromLayer(String layerName, boolean isDeadly) {
        Array<SolidBlock> blocks = new Array<>();
        MapLayer layer = tiledMap.getLayers().get(layerName);

        if (layer != null) {
            for (MapObject object : layer.getObjects()) {
                if (object instanceof RectangleMapObject) {
                    Rectangle rect = ((RectangleMapObject) object).getRectangle();
                    blocks.add(new SolidBlock(rect.x, rect.y, rect.width, rect.height, isDeadly));
                }
            }
            System.out.println("Successfully loaded " + blocks.size + " blocks from layer: " + layerName);
        } else {
            System.out.println("CRITICAL WARNING: Layer '" + layerName + "' NOT found!");
        }

        return blocks;
    }
}
