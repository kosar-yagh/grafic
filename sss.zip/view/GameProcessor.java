package com.Knight.view; // یا هر پکیجی که کنترلرهات توش هستن

import com.Knight.model.Hero;
import com.badlogic.gdx.Input;
import com.badlogic.gdx.InputAdapter;

public class GameProcessor extends InputAdapter {
    private Hero hero;

    public GameProcessor(Hero hero) {
        this.hero = hero;
    }

    @Override
    public boolean keyDown(int keycode) {

        if (keycode == GameSettings.keyMoveLeft) {
            hero.movingLeft = true;
        } else if (keycode == GameSettings.keyMoveRight) {
            hero.movingRight = true;
        } else if (keycode == GameSettings.keyJump) {
            hero.jump();
        }
        return true;
    }

    @Override
    public boolean keyUp(int keycode) {
        if (keycode == GameSettings.keyMoveLeft) {
            hero.movingLeft = false;
        } else if (keycode == GameSettings.keyMoveRight) {
            hero.movingRight = false;
        }
        return true;
    }
}
