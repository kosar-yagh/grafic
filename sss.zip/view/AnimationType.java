package com.Knight.view;

public enum AnimationType {


    // انیمیشن‌های پایه
    HOLLOW_KNIGHT_IDLE("animations/hero/Idle Hurt.png", 12, 12, 1),
    HOLLOW_KNIGHT_WALK("animations/hero/Run.png", 13, 13, 1),
    HOLLOW_KNIGHT_DASH("animations/hero/Dash.png", 12, 12, 1), // فرض بر این است که یک فایل دش دارید

    // انیمیشن‌های پرش
    HOLLOW_KNIGHT_JUMP("animations/hero/Jump.png", 4, 4, 1),
    HOLLOW_KNIGHT_DOUBLE_JUMP("animations/hero/Double Jump.png", 8, 8, 1),

    // انیمیشن‌های حمله
    HOLLOW_KNIGHT_ATTACK("animations/hero/Attack.png", 4, 4, 1),
    HOLLOW_KNIGHT_ATTACK_ALT("animations/hero/Attack.png", 4, 4, 1),
    HOLLOW_KNIGHT_UP_SLASH("animations/hero/UpSlash.png", 5, 5, 1),
    HOLLOW_KNIGHT_DOWN_SLASH("animations/hero/DownSlash.png", 5, 5, 1),

    // مهارت‌ها و سایر
    HOLLOW_KNIGHT_WALL_JUMP("animations/hero/Walljump.png", 10, 10, 1),
    HOLLOW_KNIGHT_FIREBALL("animations/hero/Fireball Cast.png", 9, 9, 1),
    HOLLOW_KNIGHT_HEAL("animations/hero/Focus Get.png", 6, 6, 1);

    public final String path;
    public final int frameCount;
    public final int colCount;
    public final int rowCount;

    AnimationType(String path, int frameCount, int colCount, int rowCount) {
        this.path = path;
        this.frameCount = frameCount;
        this.colCount = colCount;
        this.rowCount = rowCount;
    }
}
