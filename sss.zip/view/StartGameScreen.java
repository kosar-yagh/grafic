package com.Knight.view;

import com.Knight.controller.SaveManager;
import com.Knight.model.SaveData;
import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.scenes.scene2d.InputEvent;
import com.badlogic.gdx.scenes.scene2d.ui.Image;
import com.badlogic.gdx.scenes.scene2d.ui.Stack;
import com.badlogic.gdx.scenes.scene2d.ui.Table;
import com.badlogic.gdx.scenes.scene2d.ui.TextButton;
import com.badlogic.gdx.scenes.scene2d.utils.ClickListener;

public class StartGameScreen extends BaseScreen {

    @Override
    public void show() {
        super.show();

        // ۱. تنظیم پس‌زمینه
        backgroundTexture = new Texture(Gdx.files.internal("ba.png"));
        Image backgroundImage = new Image(backgroundTexture);
        backgroundImage.setFillParent(true);

        // ۲. ایجاد لایه‌بندی اصلی با Stack
        Stack stack = new Stack();
        stack.setFillParent(true);
        stack.add(backgroundImage);

        // ۳. جدول اصلی برای دکمه‌های وسط صفحه
        Table rootTable = new Table();
        rootTable.setFillParent(true);
        rootTable.center();

        rootTable.defaults().width(300).height(50).spaceBottom(100);

        // ۴. دکمه New Game
        TextButton newGameBtn = new TextButton("New Game", skin);
        newGameBtn.getLabel().setFontScale(1.5f);
        rootTable.add(newGameBtn).row();

        // ۵. جدول Load Game
        Table loadTable = new Table();
        loadTable.defaults().width(150).height(50).pad(10);
        for (int i = 1; i <= 4; i++) {
            final int slotIndex = i; // شماره اسلات
            TextButton saveSlot = new TextButton("Save " + slotIndex, skin);
            saveSlot.getLabel().setFontScale(1.5f);

            saveSlot.addListener(new ClickListener() {
                @Override
                public void clicked(InputEvent event, float x, float y) {
                    SaveManager.currentSaveSlot = slotIndex; // تنظیم اسلات فعلی
                    SaveData data = SaveManager.loadGame(slotIndex); // خواندن فایل JSON

                    if (data != null) {
                        // اگر فایل سیو وجود داشت، مپ مربوطه را باز می‌کنیم
                        // نکته: در مرحله بعد (داخل GamePlayScreen) باید موقعیت و جون هیرو رو از روی SaveManager روی hero سِت کنی
                        UiManager.setScreen(new GamePlayScreen(data.mapPath));
                    } else {
                        // اگر سیوی نبود، مانند بازی جدید عمل می‌کنیم
                        System.out.println("No save found in slot " + slotIndex + ", starting new game.");
                        UiManager.setScreen(new GamePlayScreen("newmap/mapoggraf.tmx"));
                    }
                }
            });

            loadTable.add(saveSlot);
            if (i % 2 == 0) loadTable.row();
        }

        rootTable.add(loadTable);

        // ۶. دکمه Back جداگانه پایین سمت چپ
        TextButton backBtn = new TextButton("Back", skin);
        backBtn.getLabel().setFontScale(1.5f);

        Table backTable = new Table();
        backTable.setFillParent(true);
        backTable.bottom().left();
        backTable.add(backBtn).width(180).height(50).padLeft(20).padBottom(20);

        // ۷. اضافه کردن همه چیز به Stack
        stack.add(rootTable);
        stack.add(backTable);

        stage.addActor(stack);
        Gdx.input.setInputProcessor(stage);
        // بعد از ساخت newGameBtn و قبل از خروج از show()

        newGameBtn.addListener(new ClickListener() {
            @Override
            public void clicked(InputEvent event, float x, float y) {
                // اینجا وارد گیم‌پلی می‌شیم
                UiManager.setScreen(new GamePlayScreen("newmap/mapoggraf.tmx"));


            }
        });


        // ۸. کلیک دکمه Back
        backBtn.addListener(new ClickListener() {
            @Override
            public void clicked(InputEvent event, float x, float y) {
                ((com.badlogic.gdx.Game) Gdx.app.getApplicationListener()).setScreen(new MainScreen());
            }
        });
    }

    @Override
    public void dispose() {
        if (backgroundTexture != null) backgroundTexture.dispose();
        if (stage != null) stage.dispose();
    }
}
