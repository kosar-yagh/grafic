package com.Knight.view;

import com.badlogic.gdx.Game;
import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.scenes.scene2d.InputEvent;
import com.badlogic.gdx.scenes.scene2d.ui.Image;
import com.badlogic.gdx.scenes.scene2d.ui.Stack;
import com.badlogic.gdx.scenes.scene2d.ui.Table;
import com.badlogic.gdx.scenes.scene2d.ui.TextButton;
import com.badlogic.gdx.scenes.scene2d.utils.ClickListener;

public class MainScreen extends BaseScreen {

    @Override
    public void show() {
        super.show();

        backgroundTexture = new Texture(Gdx.files.internal("background2.png"));

        if (GameSettings.backgroundMusic == null) {
            GameSettings.backgroundMusic = Gdx.audio.newMusic(Gdx.files.internal("music/crystal.mp3"));
            GameSettings.backgroundMusic.setLooping(true);
        }
        GameSettings.applySettings();

        Image backgroundImage = new Image(backgroundTexture);
        backgroundImage.setFillParent(true);

        Stack stack = new Stack();
        stack.setFillParent(true);
        stack.add(backgroundImage);

        Table exitBtnWrapper = new Table();
        exitBtnWrapper.bottom().left().padLeft(20).padBottom(70);
        TextButton exitBtn = new TextButton("Quit Game", skin);
        exitBtn.getLabel().setFontScale(2.0f);
        exitBtnWrapper.add(exitBtn).width(200).height(55);
        stack.add(exitBtnWrapper);

        Table guideBtnWrapper = new Table();
        guideBtnWrapper.bottom().right().padRight(20).padBottom(70);
        TextButton guideBtn = new TextButton("Guide", skin);
        guideBtn.getLabel().setFontScale(2.0f);
        guideBtnWrapper.add(guideBtn).width(200).height(55);
        stack.add(guideBtnWrapper);

        Table playBtnsWrapper = new Table();
        playBtnsWrapper.center();
        playBtnsWrapper.defaults().width(250).height(60).spaceBottom(30);

        TextButton startGame = new TextButton("Start Game", skin);
        startGame.getLabel().setFontScale(2.0f);

        TextButton settings = new TextButton("Settings", skin);
        settings.getLabel().setFontScale(2.0f);

        TextButton achievements = new TextButton("Achievements", skin);
        achievements.getLabel().setFontScale(2.0f);

        playBtnsWrapper.add(startGame).row();
        playBtnsWrapper.add(settings).row();
        playBtnsWrapper.add(achievements).row();

        stack.add(playBtnsWrapper);

        stage.addActor(stack);
        Gdx.input.setInputProcessor(stage);

        startGame.addListener(new ClickListener() {
            @Override
            public void clicked(InputEvent event, float x, float y) {
                ((Game) Gdx.app.getApplicationListener()).setScreen(new StartGameScreen());
            }
        });

        guideBtn.addListener(new ClickListener() {
            @Override
            public void clicked(InputEvent event, float x, float y) {
                ((Game) Gdx.app.getApplicationListener()).setScreen(new GuideScreen());
            }
        });

        settings.addListener(new ClickListener() {
            @Override
            public void clicked(InputEvent event, float x, float y) {
                ((Game) Gdx.app.getApplicationListener()).setScreen(new SettingsScreen());
            }
        });

        achievements.addListener(new ClickListener() {
            @Override
            public void clicked(InputEvent event, float x, float y) {
                ((Game) Gdx.app.getApplicationListener()).setScreen(new AchievementsScreen());
            }
        });

        exitBtn.addListener(new ClickListener() {
            @Override
            public void clicked(InputEvent event, float x, float y) {
                Gdx.app.exit();
            }
        });
    }
}
