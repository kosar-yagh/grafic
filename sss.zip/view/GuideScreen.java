package com.Knight.view;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.scenes.scene2d.InputEvent;
import com.badlogic.gdx.scenes.scene2d.ui.*;
import com.badlogic.gdx.scenes.scene2d.utils.ClickListener;

public class GuideScreen extends BaseScreen {

    @Override
    public void show() {
        super.show();


        backgroundTexture = new Texture(Gdx.files.internal("guide2.png"));
        Image bgImage = new Image(backgroundTexture);
        bgImage.setFillParent(true);


        Table rootTable = new Table();
        rootTable.setFillParent(true);
        rootTable.top().padTop(50);

        Label title = new Label("GUIDE", skin);
        title.setFontScale(2.5f);
        rootTable.add(title).padBottom(50).row();


        Table contentTable = new Table();
        contentTable.defaults().pad(15).top().left();


        Table controlsTable = new Table();
        controlsTable.defaults().left().pad(10);
        Label controlTitle = new Label("CONTROLS", skin);
        controlTitle.setFontScale(2.0f);
        controlsTable.add(controlTitle).padBottom(10).row();

        controlsTable.add(new Label("Move Left: " + GameSettings.getKeyName(GameSettings.keyMoveLeft), skin)).row();
        controlsTable.add(new Label("Move Right: " + GameSettings.getKeyName(GameSettings.keyMoveRight), skin)).row();
        controlsTable.add(new Label("Jump: " + GameSettings.getKeyName(GameSettings.keyJump), skin)).row();
        controlsTable.add(new Label("Dash: " + GameSettings.getKeyName(GameSettings.keyDash), skin)).row();
        controlsTable.add(new Label("Attack: " + GameSettings.getKeyName(GameSettings.keyNail), skin)).row();

        // --- بخش دوم: توانایی‌ها (Abilities) ---
        Table abilitiesTable = new Table();
        abilitiesTable.defaults().left().pad(10);
        Label abilTitle = new Label("ABILITIES", skin);
        abilTitle.setFontScale(2.0f);
        abilitiesTable.add(abilTitle).padBottom(10).row();

        abilitiesTable.add(new Label("- Health: Your life bar", skin)).row();
        abilitiesTable.add(new Label("- Soul: Fill by hitting enemies", skin)).row();
        abilitiesTable.add(new Label("- Knight: Your main character", skin)).row();

        // --- بخش سوم: کدهای تقلب (Cheat Codes) ---
        Table cheatTable = new Table();
        cheatTable.defaults().left().pad(10);
        Label cheatTitle = new Label("CHEATS", skin);
        cheatTitle.setFontScale(2.0f);
        cheatTable.add(cheatTitle).padBottom(10).row();

        cheatTable.add(new Label("GODMODE", skin)).row();
        cheatTable.add(new Label("INFINITE_SOUL", skin)).row();


        contentTable.add(controlsTable);
        contentTable.add(abilitiesTable).padLeft(40);
        contentTable.add(cheatTable).padLeft(40);

        rootTable.add(contentTable).padLeft(0).row();



        TextButton backBtn = new TextButton("Back", skin);
        backBtn.getLabel().setFontScale(1.5f);

        Table backTable = new Table();
        backTable.setFillParent(true);
        backTable.bottom().left();
        backTable.add(backBtn).width(180).height(50).padLeft(20).padBottom(20);


        Stack stack = new Stack();
        stack.setFillParent(true);
        stack.add(bgImage);
        stack.add(rootTable);
        stack.add(backTable);
        stage.addActor(stack);
        Gdx.input.setInputProcessor(stage);

        backBtn.addListener(new ClickListener() {
            @Override
            public void clicked(InputEvent event, float x, float y) {
                ((com.badlogic.gdx.Game) Gdx.app.getApplicationListener()).setScreen(new MainScreen());
            }
        });
    }

    @Override
    public void dispose() {
        if (backgroundTexture != null) backgroundTexture.dispose();
        if (stage != null) stage.dispose();
    }
}
