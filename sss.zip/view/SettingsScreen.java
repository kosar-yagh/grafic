package com.Knight.view;

import com.badlogic.gdx.Game;
import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.BitmapFont;
import com.badlogic.gdx.graphics.g2d.freetype.FreeTypeFontGenerator;
import com.badlogic.gdx.scenes.scene2d.Actor;
import com.badlogic.gdx.scenes.scene2d.InputEvent;
import com.badlogic.gdx.scenes.scene2d.ui.*;
import com.badlogic.gdx.scenes.scene2d.utils.ChangeListener;
import com.badlogic.gdx.scenes.scene2d.utils.ClickListener;

public class SettingsScreen extends BaseScreen {
    private BitmapFont customFont; // این متغیر فونت جدید ماست

    private Label title, musicL, sfxL, brightL, langL;
    private CheckBox musicCheck, sfxCheck;
    private Slider musicSlide, sfxSlide, brightSlide;
    private SelectBox<String> langBox;
    private TextButton backBtn, resetSfxBtn, resetKeysBtn;
    private void createFonts() {
        // 1. فایل فونت را از assets می‌خواند (نام فایل را با فونت خودت چک کن)
        FreeTypeFontGenerator generator = new FreeTypeFontGenerator(Gdx.files.internal("fonts/Zar.ttf"));
        FreeTypeFontGenerator.FreeTypeFontParameter parameter = new FreeTypeFontGenerator.FreeTypeFontParameter();

        // 2. تنظیمات اصلی
        parameter.size = 32; // سایز متن
        parameter.color = Color.WHITE; // رنگ خودِ متن

        // 3. تنظیم حاشیه (این همان بخشی است که پرسیدی)
        parameter.borderWidth = 2.0f;           // ضخامت حاشیه (هر چه بیشتر، ضخیم‌تر)
        parameter.borderColor = Color.BLACK;    // رنگ حاشیه (مشکی بهترین گزینه است)
        parameter.shadowOffsetX = 2;            // اختیاری: ایجاد کمی سایه برای عمق دادن
        parameter.shadowOffsetY = 2;
        parameter.shadowColor = new Color(0, 0, 0, 0.5f);

        // 4. حروف مجاز (بسیار مهم: حتما حروف فارسی را اینجا بنویس)
        parameter.characters = "ابپتثجحخدذرزژسشصضطظعغفقکگلمنوهی آ";

        // 5. تولید نهایی
        customFont = generator.generateFont(parameter);
        generator.dispose(); // آزاد کردن حافظه موقت
    }

    @Override
    public void show() {
        super.show();

        backgroundTexture = new Texture(Gdx.files.internal("guide2.png"));

        Table mainTable = new Table();
        mainTable.setFillParent(true);
        mainTable.center().pad(20);

        title = new Label("SETTINGS", skin);
        title.setFontScale(2.0f);

        musicL = new Label("Music", skin);
        musicSlide = new Slider(0f, 1f, 0.01f, false, skin);
        musicSlide.setValue(GameSettings.musicVolume);
        musicCheck = new CheckBox(" On", skin);
        musicCheck.setChecked(GameSettings.musicEnabled);

        sfxL = new Label("SFX", skin);
        sfxSlide = new Slider(0f, 1f, 0.01f, false, skin);
        sfxSlide.setValue(GameSettings.sfxVolume);
        sfxCheck = new CheckBox(" On", skin);
        sfxCheck.setChecked(GameSettings.sfxEnabled);

        resetSfxBtn = new TextButton("Reset SFX", skin);

        brightL = new Label("Brightness", skin);
        brightSlide = new Slider(0.1f, 1f, 0.1f, false, skin);
        brightSlide.setValue(GameSettings.brightness);

        langL = new Label("Language", skin);
        langBox = new SelectBox<>(skin);
        langBox.setItems("English", "Persian");
        langBox.setSelected(GameSettings.language);

        resetKeysBtn = new TextButton("Reset Keys", skin);
        backBtn = new TextButton("Back", skin);

        mainTable.add(title).colspan(3).padBottom(30).row();

        mainTable.add(musicL).width(150).left();
        mainTable.add(musicSlide).fillX().expandX();
        mainTable.add(musicCheck).padLeft(10).row();

        mainTable.add(sfxL).width(150).left();
        mainTable.add(sfxSlide).fillX().expandX();
        mainTable.add(sfxCheck).padLeft(10).row();

        mainTable.add(resetSfxBtn).colspan(3).padTop(10).row();

        mainTable.add(brightL).width(150).left();
        mainTable.add(brightSlide).colspan(2).fillX().expandX().row();

        mainTable.add(langL).width(150).left();
        mainTable.add(langBox).colspan(2).fillX().expandX().row();

        mainTable.add(resetKeysBtn).colspan(3).padTop(10).row();

        Table backTable = new Table();
        backTable.setFillParent(true);
        backTable.bottom().left().pad(20);
        backTable.add(backBtn).width(180).height(55);

        stage.addActor(mainTable);
        stage.addActor(backTable);

        musicSlide.addListener(new ChangeListener() {
            @Override
            public void changed(ChangeEvent event, Actor actor) {
                GameSettings.musicVolume = musicSlide.getValue();
                GameSettings.applySettings();
            }
        });

        musicCheck.addListener(new ChangeListener() {
            @Override
            public void changed(ChangeEvent event, Actor actor) {
                GameSettings.musicEnabled = musicCheck.isChecked();
                GameSettings.applySettings();
            }
        });

        sfxSlide.addListener(new ChangeListener() {
            @Override
            public void changed(ChangeEvent event, Actor actor) {
                GameSettings.sfxVolume = sfxSlide.getValue();
            }
        });

        sfxCheck.addListener(new ChangeListener() {
            @Override
            public void changed(ChangeEvent event, Actor actor) {
                GameSettings.sfxEnabled = sfxCheck.isChecked();
            }
        });

        resetSfxBtn.addListener(new ClickListener() {
            @Override
            public void clicked(InputEvent event, float x, float y) {
                GameSettings.sfxVolume = 0.5f;
                GameSettings.sfxEnabled = true;
                sfxSlide.setValue(0.5f);
                sfxCheck.setChecked(true);
            }
        });

        brightSlide.addListener(new ChangeListener() {
            @Override
            public void changed(ChangeEvent event, Actor actor) {
                GameSettings.brightness = brightSlide.getValue();
            }
        });

        langBox.addListener(new ChangeListener() {
            @Override
            public void changed(ChangeEvent event, Actor actor) {
                GameSettings.language = langBox.getSelected();
                refreshTexts();
            }
        });

        resetKeysBtn.addListener(new ClickListener() {
            @Override
            public void clicked(InputEvent event, float x, float y) {
                GameSettings.resetKeys();
            }
        });

        backBtn.addListener(new ClickListener() {
            @Override
            public void clicked(InputEvent event, float x, float y) {
                ((Game) Gdx.app.getApplicationListener()).setScreen(new MainScreen());
            }
        });

        Gdx.input.setInputProcessor(stage);
        refreshTexts();
    }

    private void refreshTexts() {
        if ("Persian".equals(GameSettings.language)) {
            title.setText("تنظیمات");
            musicL.setText("موزیک");
            sfxL.setText("افکت صدا");
            brightL.setText("روشنایی");
            langL.setText("زبان");
            resetSfxBtn.setText("ریست صدا");
            resetKeysBtn.setText("ریست کلیدها");
            backBtn.setText("بازگشت");
        } else {
            title.setText("SETTINGS");
            musicL.setText("Music");
            sfxL.setText("SFX");
            brightL.setText("Brightness");
            langL.setText("Language");
            resetSfxBtn.setText("Reset SFX");
            resetKeysBtn.setText("Reset Keys");
            backBtn.setText("Back");
        }
    }
}
