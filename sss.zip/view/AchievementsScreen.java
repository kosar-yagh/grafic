package com.Knight.view;

public class AchievementsScreen extends BaseScreen {
}
