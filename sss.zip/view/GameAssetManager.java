package com.Knight.view;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.Animation;
import com.badlogic.gdx.graphics.g2d.TextureRegion;
import com.badlogic.gdx.utils.ObjectMap;

public class GameAssetManager {

    public static ObjectMap<AnimationType, Animation<TextureRegion>> animationMap = new ObjectMap<>();


    public static void loadAnimations() {
        for (AnimationType type : AnimationType.values()) {
            Texture texture = new Texture(Gdx.files.internal(type.path));

            TextureRegion[][] tmp = TextureRegion.split(texture,
                texture.getWidth() / type.colCount,
                texture.getHeight() / type.rowCount);

            TextureRegion[] frames = new TextureRegion[type.frameCount];
            int index = 0;
            for (int i = 0; i < type.rowCount; i++) {
                for (int j = 0; j < type.colCount; j++) {
                    if (index < type.frameCount) {
                        frames[index++] = tmp[i][j];
                    }
                }
            }

            Animation<TextureRegion> anim = new Animation<>(0.1f, frames);
            animationMap.put(type, anim);
        }
    }
}
