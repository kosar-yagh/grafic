package com.Knight;

import com.Knight.model.AchievementObserver;
import com.Knight.view.MainScreen;
import com.Knight.view.UiManager;
import com.badlogic.gdx.Game;
import com.badlogic.gdx.utils.ScreenUtils;

import java.util.ArrayList;
import java.util.List;

public class Mainn extends Game {

    @Override
    public void create() {
        UiManager.init(this);
        MainScreen mainScreen=new MainScreen();
        setScreen(mainScreen);
    }

    @Override
    public void render(){
        ScreenUtils.clear(0,0,0,0);
        super.render();
        }
    }

