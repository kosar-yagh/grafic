package com.Knight.controller;

import com.Knight.model.CrystalCrawlerModel;
import com.Knight.model.Hero;
import com.Knight.model.SolidBlock;
import com.badlogic.gdx.utils.Array;

public class CrystalCrawlerController {
    private static final float SPEED = 50f;
    private static final float GRAVITY = -450f;

    public void update(float delta, CrystalCrawlerModel crawler, Hero hero, Array<SolidBlock> blocks, CombatController combatController) {
        crawler.stateTime += delta;

        if (crawler.damageCooldown > 0) crawler.damageCooldown -= delta;

        // 🌟 بررسی مرگ
        if (crawler.hp <= 0 && crawler.currentState != CrystalCrawlerModel.State.DEAD && crawler.currentState != CrystalCrawlerModel.State.DYING) {
            crawler.currentState = CrystalCrawlerModel.State.DYING;
            crawler.stateTime = 0;
        }

        if (crawler.currentState == CrystalCrawlerModel.State.DEAD) {
            crawler.velocity.x = 0;
        } else if (crawler.currentState == CrystalCrawlerModel.State.DYING) {
            crawler.velocity.x = 0;
            if (crawler.stateTime > 0.4f) {
                crawler.currentState = CrystalCrawlerModel.State.DEAD;
                crawler.stateTime = 0;
            }
        }

        crawler.velocity.y += GRAVITY * delta;

        crawler.position.y += crawler.velocity.y * delta;
        crawler.bounds.setPosition(crawler.position.x, crawler.position.y);

        boolean isGrounded = false;
        for (SolidBlock block : blocks) {
            if (crawler.bounds.overlaps(block.bounds)) {
                if (crawler.velocity.y <= 0) {
                    crawler.position.y = block.bounds.y + block.bounds.height;
                    isGrounded = true;
                } else {
                    crawler.position.y = block.bounds.y - crawler.bounds.height;
                }
                crawler.velocity.y = 0;
                crawler.bounds.setPosition(crawler.position.x, crawler.position.y);
                break;
            }
        }

        if (crawler.currentState == CrystalCrawlerModel.State.WALKING) {
            crawler.velocity.x = crawler.facingLeft ? -SPEED : SPEED;

            if (crawler.bounds.overlaps(hero.bounds) && crawler.damageCooldown <= 0) {
                if (combatController != null && !combatController.isHeroInvincible()) {
                    hero.currentHealth -= 1;
                    crawler.damageCooldown = 1.0f;
                    hero.position.x += crawler.facingLeft ? -25f : 25f;
                }
            }
        }

        if (crawler.currentState != CrystalCrawlerModel.State.DEAD && crawler.currentState != CrystalCrawlerModel.State.DYING) {
            float oldX = crawler.position.x;
            crawler.position.x += crawler.velocity.x * delta;
            crawler.bounds.setPosition(crawler.position.x, crawler.position.y);

            boolean hitWall = false;
            for (SolidBlock block : blocks) {
                if (crawler.bounds.overlaps(block.bounds)) {
                    hitWall = true;
                    break;
                }
            }

            boolean groundAhead = false;
            if (crawler.currentState == CrystalCrawlerModel.State.WALKING && isGrounded) {
                float checkX = crawler.facingLeft ? crawler.bounds.x - 4f : crawler.bounds.x + crawler.bounds.width + 4f;
                float checkY = crawler.bounds.y - 4f;

                for (SolidBlock block : blocks) {
                    if (block.bounds.contains(checkX, checkY)) {
                        groundAhead = true;
                        break;
                    }
                }
            } else {
                groundAhead = true;
            }

            if (hitWall || !groundAhead) {
                crawler.position.x = oldX;
                crawler.bounds.setPosition(crawler.position.x, crawler.position.y);
                if (crawler.currentState == CrystalCrawlerModel.State.WALKING) {
                    crawler.facingLeft = !crawler.facingLeft;
                }
            }
        }
    }
}
