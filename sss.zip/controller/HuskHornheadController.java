package com.Knight.controller;

import com.Knight.model.Hero;
import com.Knight.model.HuskHornheadModel;
import com.Knight.model.SolidBlock;
import com.badlogic.gdx.utils.Array;

public class HuskHornheadController {
    private static final float WALK_SPEED = 50f;
    private static final float CHARGE_SPEED = 320f;
    private static final float WALK_DURATION = 3f;
    private static final float REST_DURATION = 2f;

    public void update(float delta, HuskHornheadModel enemy, Hero hero, Array<SolidBlock> blocks, CombatController combatController) {
        enemy.stateTime += delta;

        if (enemy.damageCooldown > 0) {
            enemy.damageCooldown -= delta;
        }

        // 🌟 بررسی مرگ
        if (enemy.hp <= 0 && enemy.currentState != HuskHornheadModel.State.DEAD) {
            changeState(enemy, HuskHornheadModel.State.DEAD);
        }

        // اعمال جاذبه برای ایستادن یا افتادن جسد روی زمین
        enemy.velocity.y -= 400 * delta;

        if (enemy.currentState != HuskHornheadModel.State.DEAD) {
            switch (enemy.currentState) {
                case WALKING:
                    enemy.velocity.x = enemy.facingLeft ? -WALK_SPEED : WALK_SPEED;
                    if (enemy.stateTime >= WALK_DURATION) {
                        changeState(enemy, HuskHornheadModel.State.RESTING);
                    }
                    checkForPlayer(enemy, hero);
                    break;

                case RESTING:
                    enemy.velocity.x = 0;
                    if (enemy.stateTime >= REST_DURATION) {
                        //  به جای تغییر جهت ناگهانی، به حالت چرخش می‌رود
                        changeState(enemy, HuskHornheadModel.State.TURNING);
                    }
                    checkForPlayer(enemy, hero);
                    break;

                case TURNING:
                    enemy.velocity.x = 0; // در حین چرخش توقف می‌کند
                    // پس از 0.2 ثانیه (زمان پخش انیمیشن Turn) جهت را عوض کرده و راه می‌افتد
                    if (enemy.stateTime >= 0.2f) {
                        enemy.facingLeft = !enemy.facingLeft;
                        changeState(enemy, HuskHornheadModel.State.WALKING);
                    }
                    break;

                case CHARGING:
                    enemy.velocity.x = enemy.facingLeft ? -CHARGE_SPEED : CHARGE_SPEED;
                    break;
            }
        } else {
            enemy.velocity.x = 0; // جسد حرکت افقی ندارد
        }

        float oldX = enemy.position.x;
        enemy.position.x += enemy.velocity.x * delta;
        enemy.bounds.setPosition(enemy.position.x, enemy.position.y);

        boolean hitWall = false;
        for (SolidBlock block : blocks) {
            if (enemy.bounds.overlaps(block.bounds)) {
                if (enemy.position.y < block.bounds.y + block.bounds.height - 4 &&
                    enemy.position.y + enemy.bounds.height > block.bounds.y + 4) {
                    hitWall = true;
                    enemy.position.x = oldX;
                    enemy.bounds.setPosition(enemy.position.x, enemy.position.y);
                    break;
                }
            }
        }

        float oldY = enemy.position.y;
        enemy.position.y += enemy.velocity.y * delta;
        enemy.bounds.setPosition(enemy.position.x, enemy.position.y);

        for (SolidBlock block : blocks) {
            if (enemy.bounds.overlaps(block.bounds)) {
                if (enemy.velocity.y <= 0) {
                    enemy.velocity.y = 0;
                    enemy.position.y = block.bounds.y + block.bounds.height;
                    enemy.bounds.setPosition(enemy.position.x, enemy.position.y);
                } else if (enemy.velocity.y > 0) {
                    enemy.velocity.y = 0;
                    enemy.position.y = block.bounds.y - enemy.bounds.height;
                    enemy.bounds.setPosition(enemy.position.x, enemy.position.y);
                }
            }
        }

        if (enemy.currentState == HuskHornheadModel.State.CHARGING && hitWall) {
            changeState(enemy, HuskHornheadModel.State.TURNING);
            enemy.facingLeft = !enemy.facingLeft;
            changeState(enemy, HuskHornheadModel.State.RESTING);
        }

        if (enemy.currentState != HuskHornheadModel.State.DEAD && enemy.bounds.overlaps(hero.bounds) && enemy.damageCooldown <= 0) {
            if (combatController != null && !combatController.isHeroInvincible()) {
                hero.currentHealth -= 1;
                enemy.damageCooldown = 1.5f;

                float knockbackDir = (hero.position.x > enemy.position.x) ? 35f : -35f;
                hero.position.x += knockbackDir;
                hero.position.y += 10f;
            }
        }
    }

    private void checkForPlayer(HuskHornheadModel enemy, Hero hero) {
        if (enemy.visionZone.overlaps(hero.bounds)) {
            boolean heroInFront = enemy.facingLeft ? (hero.position.x < enemy.position.x) : (hero.position.x > enemy.position.x);
            if (heroInFront) {
                changeState(enemy, HuskHornheadModel.State.CHARGING);
            }
        }
    }

    private void changeState(HuskHornheadModel enemy, HuskHornheadModel.State newState) {
        enemy.currentState = newState;
        enemy.stateTime = 0;
    }
}
