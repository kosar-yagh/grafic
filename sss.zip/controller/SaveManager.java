package com.Knight.controller;

import com.Knight.model.Hero;
import com.Knight.model.SaveData;
import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.files.FileHandle;
import com.badlogic.gdx.utils.Json;

public class SaveManager {

    // شماره اسلات سیو که کاربر الان در حال بازی روی آن است (1 تا 4)
    public static int currentSaveSlot = 1;

    public static void saveGame(Hero hero, String mapPath) {
        SaveData data = new SaveData();
        data.heroX = hero.position.x;
        data.heroY = hero.position.y;
        data.currentHealth = hero.currentHealth;
        data.mapPath = mapPath;

        Json json = new Json();
        String jsonText = json.toJson(data);

        // ذخیره در پوشه سیستمی بازی
        FileHandle file = Gdx.files.local("saves/slot_" + currentSaveSlot + ".json");
        file.writeString(jsonText, false);
        System.out.println(" Game Saved Successfully to Slot " + currentSaveSlot);
    }

    public static SaveData loadGame(int slot) {
        FileHandle file = Gdx.files.local("saves/slot_" + slot + ".json");
        if (file.exists()) {
            Json json = new Json();
            System.out.println(" Game Loaded from Slot " + slot);
            return json.fromJson(SaveData.class, file.readString());
        }
        return null; // اگر سیوی وجود نداشت
    }
}
