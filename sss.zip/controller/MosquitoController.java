package com.Knight.controller;

import com.Knight.model.Hero;
import com.Knight.model.MosquitoModel;
import com.Knight.model.SolidBlock;
import com.badlogic.gdx.math.Vector2;
import com.badlogic.gdx.utils.Array;

public class MosquitoController {

    public void update(float delta, MosquitoModel m, Hero hero, Array<SolidBlock> blocks) {
        if (m.currentState == MosquitoModel.State.DEAD) return;

        m.stateTime += delta;

        if (m.hp <= 0 && m.currentState != MosquitoModel.State.DYING && m.currentState != MosquitoModel.State.DEAD) {
            m.die();
        }

        if (m.currentState == MosquitoModel.State.DYING) {
            m.velocity.y -= 1000 * delta;
            m.position.y += m.velocity.y * delta;
            m.bounds.setPosition(m.position.x, m.position.y);

            for (SolidBlock block : blocks) {
                if (m.bounds.overlaps(block.bounds)) {
                    m.position.y = block.bounds.y + block.bounds.height;
                    m.bounds.setPosition(m.position.x, m.position.y);
                    m.currentState = MosquitoModel.State.DEAD;
                    break;
                }
            }
            return;
        }

        switch (m.currentState) {
            case IDLE:
                if (m.aggroZone != null && m.aggroZone.overlaps(hero.bounds)) {
                    Vector2 target = new Vector2(hero.position.x, hero.position.y);
                    m.dashDirection.set(target).sub(m.position).nor();

                    //  بررسی نیاز به چرخش قبل از حمله
                    boolean shouldFaceLeft = m.dashDirection.x < 0;
                    if (m.facingLeft != shouldFaceLeft) {
                        m.currentState = MosquitoModel.State.TURNING;
                        m.stateTime = 0;
                    } else {
                        m.currentState = MosquitoModel.State.ANTICIPATE;
                        m.stateTime = 0;
                    }
                }
                break;

            case TURNING:
                //  بعد از 0.2 ثانیه چرخش تکمیل می‌شود
                if (m.stateTime > 0.2f) {
                    m.facingLeft = !m.facingLeft;
                    m.currentState = MosquitoModel.State.ANTICIPATE;
                    m.stateTime = 0;
                }
                break;

            case ANTICIPATE:
                if (m.stateTime > 0.5f) {
                    m.currentState = MosquitoModel.State.ATTACKING;
                    m.stateTime = 0;
                }
                break;

            case ATTACKING:
                float speed = 350f;
                m.position.add(m.dashDirection.x * speed * delta, m.dashDirection.y * speed * delta);
                m.bounds.setPosition(m.position.x, m.position.y);

                boolean hitObstacle = false;
                for (SolidBlock block : blocks) {
                    if (m.bounds.overlaps(block.bounds)) {
                        hitObstacle = true;
                        break;
                    }
                }

                if (hitObstacle || m.stateTime > 1.5f) {
                    m.currentState = MosquitoModel.State.IDLE;
                    m.stateTime = 0;
                }
                break;
        }
    }
}
