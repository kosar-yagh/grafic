package com.Knight.controller;

import com.Knight.model.Hero;
import com.badlogic.gdx.InputAdapter;

public class GameProcessor extends InputAdapter {
    private Hero hero;

    public GameProcessor(Hero hero) {
        this.hero = hero;
    }

    // دیگر نیازی به keyDown و keyUp در اینجا نیست، زیرا کلاس Hero مستقیم کلیدها را می‌خواند

    @Override
    public boolean touchDown(int screenX, int screenY, int pointer, int button) {
        // برای مواقعی که می‌خواهید با کلیک موس پرش را تست کنید
        hero.jump();
        return true;
    }
}
