package com.Knight.controller;

import com.Knight.model.FalseKnightModel;
import com.Knight.model.Hero;
import com.badlogic.gdx.math.MathUtils;

public class FalseKnightController {

    private float baseRunSpeed = 150f;
    private float baseJumpVelocity = 400f;
    private float gravity = -600f;

    public void update(float delta, FalseKnightModel boss, Hero hero) {
        boss.stateTime += delta;
        boss.actionTimer -= delta;
        boss.triggerCameraShake = false;

        if (boss.damageTimer > 0) {
            boss.damageTimer -= delta;
        } else {
            boss.recentDamageTaken = 0;
        }

        // اعمال جاذبه فیزیکی
        if (boss.position.y > boss.floorY) {
            boss.velocity.y += gravity * delta;
        } else {
            // وقتی باس به زمین می‌رسد
            if (boss.velocity.y < 0 && (boss.currentState == FalseKnightModel.State.OFFENSIVE_LEAP ||
                boss.currentState == FalseKnightModel.State.POWER_SLAM ||
                boss.currentState == FalseKnightModel.State.JUMP_ATTACK)) {

                boss.triggerCameraShake = true; // لرزش دوربین هنگام فرود سنگین
            }
            boss.position.y = boss.floorY;
            boss.velocity.y = 0;
        }

        // حرکت افقی و عمودی
        boss.position.x += boss.velocity.x * delta;
        boss.position.y += boss.velocity.y * delta;


        //  منطق قفل شدن در محیط (ArenaLogic Boundary)
        // جلوگیری از خروج شوالیه دروغین از سمت چپ و راست مستطیل ArenaLogic
        boss.position.x = MathUtils.clamp(boss.position.x, boss.arenaLeftLimit, boss.arenaRightLimit - boss.bounds.width);

        // اگر در حال دویدن هجومی بود و به دیوار نامرئی محیط رسید، حرکت را متوقف کن
        if (boss.currentState == FalseKnightModel.State.CHARGE_RUN) {
            if (boss.position.x <= boss.arenaLeftLimit || boss.position.x >= boss.arenaRightLimit - boss.bounds.width) {
                boss.velocity.x = 0;
            }
        }

        boss.bounds.setPosition(boss.position.x, boss.position.y);

        // ۱. مکانیزم گیج شدن (Stun)
        if (!boss.isPhaseTwo && boss.currentHp <= boss.maxHp / 2 && boss.currentState != FalseKnightModel.State.STUNNED) {
            triggerStun(boss);
            return;
        }

        if (boss.currentState == FalseKnightModel.State.STUNNED) {
            boss.velocity.x = 0;
            boss.maggotHitbox.setPosition(boss.position.x + 60, boss.position.y + 10);

            if (boss.stateTime > 5.0f) {
                boss.currentState = FalseKnightModel.State.STUN_RECOVER; // رفتن به انیمیشن بلند شدن
                boss.stateTime = 0;
            }
            return;
        }

        // تغییر وضعیت از Recover به حالت عادی و شروع فاز دوم
        if (boss.currentState == FalseKnightModel.State.STUN_RECOVER && boss.stateTime > 1.5f) {
            boss.currentState = FalseKnightModel.State.IDLE;
            boss.isPhaseTwo = true;
            boss.actionTimer = 0.5f;
            boss.recentDamageTaken = 0;
        }

        // ۲. سیستم تصمیم‌گیری مبتنی بر فاصله
        if (boss.currentState == FalseKnightModel.State.IDLE && boss.actionTimer <= 0 && boss.position.y <= boss.floorY) {
            decideNextMove(boss, hero);
        }

        // ۳. اجرای حرکات باس
        executeCurrentState(delta, boss);
    }

    public void takeDamage(FalseKnightModel boss, int damage) {
        if (boss.currentState == FalseKnightModel.State.STUNNED) {
            boss.currentHp -= damage; // ضربه به مگوت
        } else {
            boss.currentHp -= damage; // ضربه به زره
            boss.recentDamageTaken += damage;
            boss.damageTimer = 1.5f;
        }
    }

    private void decideNextMove(FalseKnightModel boss, Hero hero) {
        float distance = Math.abs(hero.position.x - boss.position.x);
        boss.facingLeft = hero.position.x < boss.position.x;

        FalseKnightModel.State nextMove = FalseKnightModel.State.IDLE;
        int rand = MathUtils.random(1, 100);

        if (boss.recentDamageTaken >= 15) {
            nextMove = FalseKnightModel.State.DEFENSIVE_LEAP;
            boss.recentDamageTaken = 0;
        } else {
            if (distance < 120f) {
                // بازیکن نزدیک است
                if (rand <= 50) nextMove = FalseKnightModel.State.MACE_SLAM;
                else if (rand <= 80) nextMove = FalseKnightModel.State.DEFENSIVE_LEAP;
                else nextMove = FalseKnightModel.State.JUMP_ATTACK;
            } else {
                // بازیکن دور است
                if (rand <= 50) nextMove = FalseKnightModel.State.CHARGE_RUN;
                else if (rand <= 90) nextMove = FalseKnightModel.State.OFFENSIVE_LEAP;
                else nextMove = FalseKnightModel.State.MACE_SLAM;
            }
        }

        // جایگزینی با حمله قدرتی فاز دوم
        if (boss.isPhaseTwo && nextMove == FalseKnightModel.State.MACE_SLAM && MathUtils.randomBoolean(0.5f)) {
            nextMove = FalseKnightModel.State.POWER_SLAM;
        }

        // مکانیزم ضد اسپم (Anti-Spam)
        if (nextMove == boss.lastState) {
            nextMove = (distance < 150f) ? FalseKnightModel.State.DEFENSIVE_LEAP : FalseKnightModel.State.OFFENSIVE_LEAP;
        }

        boss.currentState = nextMove;
        boss.lastState = nextMove;
        boss.stateTime = 0;

        setupMovePhysics(boss);
    }

    private void setupMovePhysics(FalseKnightModel boss) {
        float speedMultiplier = boss.isPhaseTwo ? 1.4f : 1.0f;

        switch (boss.currentState) {
            case CHARGE_RUN:
                boss.velocity.x = boss.facingLeft ? -baseRunSpeed * speedMultiplier : baseRunSpeed * speedMultiplier;
                boss.actionTimer = 2.0f;
                break;
            case OFFENSIVE_LEAP:
            case JUMP_ATTACK:
                boss.velocity.y = baseJumpVelocity;
                boss.velocity.x = boss.facingLeft ? -130f * speedMultiplier : 130f * speedMultiplier;
                boss.actionTimer = 1.2f;
                break;
            case DEFENSIVE_LEAP:
                boss.velocity.y = baseJumpVelocity * 0.8f;
                boss.velocity.x = boss.facingLeft ? 160f : -160f;
                boss.actionTimer = 1.0f;
                break;
            case MACE_SLAM:
                boss.velocity.x = 0;
                boss.actionTimer = 1.0f / speedMultiplier;
                break;
            case POWER_SLAM:
                boss.velocity.y = baseJumpVelocity * 1.3f;
                boss.velocity.x = boss.facingLeft ? -80f : 80f;
                boss.actionTimer = 1.5f / speedMultiplier;
                break;
            default:
                boss.velocity.x = 0;
                break;
        }
    }

    private void executeCurrentState(float delta, FalseKnightModel boss) {
        if (boss.currentState != FalseKnightModel.State.IDLE &&
            boss.currentState != FalseKnightModel.State.STUNNED &&
            boss.currentState != FalseKnightModel.State.STUN_RECOVER &&
            boss.actionTimer <= 0 && boss.position.y <= boss.floorY) {

            if (boss.currentState == FalseKnightModel.State.MACE_SLAM) {
                boss.triggerCameraShake = true;
            }

            boss.currentState = FalseKnightModel.State.IDLE;
            boss.velocity.x = 0;
            boss.actionTimer = boss.isPhaseTwo ? 0.3f : 0.7f;
        }
    }

    private void triggerStun(FalseKnightModel boss) {
        boss.currentState = FalseKnightModel.State.STUNNED;
        boss.stateTime = 0;
        boss.velocity.x = 0;
        boss.velocity.y = 0;
    }
}
