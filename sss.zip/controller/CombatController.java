package com.Knight.controller;

import com.Knight.model.Hero;
import com.Knight.model.ZoteModel;
import com.Knight.model.Crawlid;
import com.Knight.model.MosquitoModel;
import com.Knight.model.CrystalCrawlerModel;
import com.Knight.model.FalseKnightModel;
import com.Knight.model.CrystalGuardianModel;
import com.Knight.model.HuskHornheadModel;
import com.badlogic.gdx.math.Rectangle;
import com.badlogic.gdx.utils.Array;
import com.Knight.model.VengefulSpiritModel;
import com.Knight.model.HowlingWraithsModel;
public class CombatController {

    private Hero hero;
    private boolean isHeroInvincible = false;
    private float invincibilityTimer = 0f;
    private static final float INVINCIBILITY_DURATION = 1.0f;

    private boolean hasDamagedBossThisSwing = false;

    public CombatController(Hero hero) {
        this.hero = hero;
    }

    //  آپدیت متد برای پشتیبانی از تمام دشمنان از جمله Husk Hornhead
    public void update(float delta, Array<?> crawlids, Array<?> mosquitos, Array<?> crystalCrawlers, Array<?> guardians, Array<?> hornheads) {
        if (isHeroInvincible) {
            invincibilityTimer -= delta;
            if (invincibilityTimer <= 0) {
                isHeroInvincible = false;
            }
        }

        Rectangle attackBounds = getNailHitbox();

        handleEnemyCombat(crawlids, attackBounds);
        handleEnemyCombat(mosquitos, attackBounds);
        handleEnemyCombat(crystalCrawlers, attackBounds);
        handleEnemyCombat(guardians, attackBounds);
        handleEnemyCombat(hornheads, attackBounds);
        // اضافه شدن دشمن شاخدار
    }

    private void handleEnemyCombat(Array<?> enemies, Rectangle attackBounds) {
        if (enemies == null) return;

        for (int i = enemies.size - 1; i >= 0; i--) {
            Object enemy = enemies.get(i);
            Rectangle enemyBounds = getBoundsFromObject(enemy);

            if (enemyBounds == null) continue;

            boolean isDead = false;
            if (enemy instanceof Crawlid) {
                Crawlid c = (Crawlid) enemy;
                isDead = (c.currentState == Crawlid.State.DEATH_LAND || c.currentState == Crawlid.State.DEATH_AIR);
            } else if (enemy instanceof MosquitoModel) {
                MosquitoModel m = (MosquitoModel) enemy;
                isDead = (m.currentState == MosquitoModel.State.DEAD || m.currentState == MosquitoModel.State.DYING);
            } else if (enemy instanceof CrystalCrawlerModel) {
                CrystalCrawlerModel cc = (CrystalCrawlerModel) enemy;
                isDead = (cc.currentState == CrystalCrawlerModel.State.DEAD || cc.currentState == CrystalCrawlerModel.State.DYING);
            } else if (enemy instanceof CrystalGuardianModel) {
                CrystalGuardianModel cg = (CrystalGuardianModel) enemy;
                isDead = (cg.currentState == CrystalGuardianModel.State.DEAD);
            } else if (enemy instanceof HuskHornheadModel) {
                HuskHornheadModel hh = (HuskHornheadModel) enemy;
                isDead = (hh.currentState == HuskHornheadModel.State.DEAD);
            }

            if (isDead) continue;

            // برخورد شمشیر شوالیه با دشمنان
            // برخورد شمشیر شوالیه با دشمنان
            if (hero.isAttacking && attackBounds != null && attackBounds.overlaps(enemyBounds)) {
                boolean hitLanded = false;
                // بررسی اینکه آیا ضربه موفق بود

                if (enemy instanceof Crawlid) {
                    ((Crawlid) enemy).currentState = Crawlid.State.DEATH_LAND;
                    ((Crawlid) enemy).stateTime = 0;
                    hitLanded = true;
                } else if (enemy instanceof MosquitoModel) {
                    ((MosquitoModel) enemy).currentState = MosquitoModel.State.DYING;
                    ((MosquitoModel) enemy).stateTime = 0;
                    hitLanded = true;
                } else if (enemy instanceof CrystalCrawlerModel) {
                    ((CrystalCrawlerModel) enemy).currentState = CrystalCrawlerModel.State.DYING;
                    ((CrystalCrawlerModel) enemy).stateTime = 0;
                    ((CrystalCrawlerModel) enemy).hp = 0;
                    hitLanded = true;
                } else if (enemy instanceof CrystalGuardianModel) {
                    ((CrystalGuardianModel) enemy).currentState = CrystalGuardianModel.State.DEAD;
                    ((CrystalGuardianModel) enemy).stateTime = 0;
                    ((CrystalGuardianModel) enemy).hp = 0;
                    hitLanded = true;
                } else if (enemy instanceof HuskHornheadModel) {
                    ((HuskHornheadModel) enemy).currentState = HuskHornheadModel.State.DEAD;
                    ((HuskHornheadModel) enemy).stateTime = 0;
                    ((HuskHornheadModel) enemy).hp = 0;
                    hitLanded = true;
                }

                // دریافت ۱۱ روح با هر ضربه موفق به دشمن (تا سقف ۹۹)
                if (hitLanded) {
                    hero.soul = Math.min(hero.soul + 11, hero.maxSoul);
                }
                continue;
            }
            // برخورد بدن دشمنان با شوالیه
            if (!isHeroInvincible && enemyBounds.overlaps(hero.bounds)) {
                hero.currentHealth -= 1;
                setHeroInvincible(true);
                hero.position.x += hero.facingRight ? -25f : 25f;
            }
        }
    }

    public void handleFalseKnightCombat(FalseKnightModel falseKnight, FalseKnightController fkController) {
        if (falseKnight == null || falseKnight.bounds == null) return;

        Rectangle attackBounds = getNailHitbox();

        if (hero.isAttacking) {
            if (!hasDamagedBossThisSwing && attackBounds != null) {
                boolean hitLanded = false;

                if (falseKnight.currentState == FalseKnightModel.State.STUNNED) {
                    if (attackBounds.overlaps(falseKnight.maggotHitbox)) {
                        hitLanded = true;
                        System.out.println("💥 Critical Hit on Maggot!");
                    }
                }
                else if (attackBounds.overlaps(falseKnight.bounds)) {
                    hitLanded = true;
                    System.out.println("⚔️ Hit on Boss Armor!");
                }

                if (hitLanded) {
                    fkController.takeDamage(falseKnight, 1);
                    hasDamagedBossThisSwing = true;
                    hero.soul = Math.min(hero.soul + 11, hero.maxSoul);
                }
            }
        } else {
            hasDamagedBossThisSwing = false;
        }

        if (!isHeroInvincible && falseKnight.bounds.overlaps(hero.bounds)) {
            if (falseKnight.currentState != FalseKnightModel.State.STUNNED && falseKnight.currentState != FalseKnightModel.State.DEAD) {
                hero.currentHealth -= 1;
                setHeroInvincible(true);
                hero.position.x += hero.facingRight ? -45f : 45f;
                hero.velocity.y = 150f;
            }
        }

    }

    public void handleZoteCombat(ZoteModel zote) {
        Rectangle attackBounds = getNailHitbox();
        if (attackBounds != null && zote != null && attackBounds.overlaps(zote.bounds)) {
            if (zote.currentState != ZoteModel.State.FALLING && zote.currentState != ZoteModel.State.GET_UP) {
                zote.currentState = ZoteModel.State.FALLING;
                zote.stateTime = 0;
                zote.showDialogue = false;
                zote.velocity.y = 200f;
                zote.velocity.x = hero.facingRight ? 150f : -150f;
            }
        }
    }

    private Rectangle getBoundsFromObject(Object obj) {
        try {
            return (Rectangle) obj.getClass().getField("bounds").get(obj);
        } catch (Exception e) {
            try {
                return (Rectangle) obj.getClass().getMethod("getBounds").invoke(obj);
            } catch (Exception ex) {
                return null;
            }
        }
    }

    public boolean isHeroAttacking() {
        return hero.isAttacking;
    }

    public Rectangle getNailHitbox() {
        if (hero.isAttacking) {
            float attackRange = 40f;
            float attackX = hero.facingRight ? hero.position.x + hero.bounds.width : hero.position.x - attackRange;
            return new Rectangle(attackX, hero.position.y, attackRange, hero.bounds.height);
        }
        return null;
    }

    public boolean isHeroInvincible() {
        return isHeroInvincible;
    }

    public void setHeroInvincible(boolean invincible) {
        this.isHeroInvincible = invincible;
        if (invincible) {
            this.invincibilityTimer = INVINCIBILITY_DURATION;
        }
    }

    //  سیستم دمیج دادن جادوها به تمام دشمنان

    public void handleSpells(Array<VengefulSpiritModel> vsList, Array<HowlingWraithsModel> hwList,
                             Array<?> crawlids, Array<?> mosquitos, Array<?> crystalCrawlers,
                             Array<?> guardians, Array<?> hornheads, FalseKnightModel falseKnight, FalseKnightController fkController) {

        Array<Object> allEnemies = new Array<>();
        if (crawlids != null) allEnemies.addAll(crawlids);
        if (mosquitos != null) allEnemies.addAll(mosquitos);
        if (crystalCrawlers != null) allEnemies.addAll(crystalCrawlers);
        if (guardians != null) allEnemies.addAll(guardians);
        if (hornheads != null) allEnemies.addAll(hornheads);

        // ۱. دمیج Vengeful Spirit (عبور از دشمنان و دمیج به هرکدام یک‌بار)
        for (VengefulSpiritModel vs : vsList) {
            if (!vs.active) continue;
            for (Object enemy : allEnemies) {
                Rectangle bounds = getBoundsFromObject(enemy);
                if (bounds != null && vs.bounds.overlaps(bounds) && !vs.hitEnemies.contains(enemy)) {
                    applyDamageToEnemy(enemy);
                    vs.hitEnemies.add(enemy);
                }
            }
            if (falseKnight != null && falseKnight.currentState != FalseKnightModel.State.DEAD) {
                if (vs.bounds.overlaps(falseKnight.bounds) && !vs.hitEnemies.contains(falseKnight)) {
                    fkController.takeDamage(falseKnight, 2); // دمیج جادو به باس بیشتر است
                    vs.hitEnemies.add(falseKnight);
                }
            }
        }

        // ۲. دمیج Howling Wraiths (سه تیک متوالی و سریع)
        for (HowlingWraithsModel hw : hwList) {
            if (!hw.active) continue;
            if (hw.tickTimer >= 0.15f && hw.ticks < 3) {
                hw.ticks++;
                hw.tickTimer = 0;
                for (Object enemy : allEnemies) {
                    Rectangle bounds = getBoundsFromObject(enemy);
                    if (bounds != null && hw.bounds.overlaps(bounds)) {
                        applyDamageToEnemy(enemy);
                    }
                }
                if (falseKnight != null && falseKnight.currentState != FalseKnightModel.State.DEAD) {
                    if (hw.bounds.overlaps(falseKnight.bounds)) {
                        fkController.takeDamage(falseKnight, 1);
                    }
                }
            }
        }
    }

    private void applyDamageToEnemy(Object enemy) {
        if (enemy instanceof Crawlid) {
            ((Crawlid) enemy).currentState = Crawlid.State.DEATH_LAND;
            ((Crawlid) enemy).stateTime = 0;
        } else if (enemy instanceof MosquitoModel) {
            ((MosquitoModel) enemy).currentState = MosquitoModel.State.DYING;
            ((MosquitoModel) enemy).stateTime = 0;
        } else if (enemy instanceof CrystalCrawlerModel) {
            ((CrystalCrawlerModel) enemy).hp -= 15;
        } else if (enemy instanceof CrystalGuardianModel) {
            ((CrystalGuardianModel) enemy).hp -= 15;
        } else if (enemy instanceof HuskHornheadModel) {
            ((HuskHornheadModel) enemy).hp -= 15;
        }
    }
}
