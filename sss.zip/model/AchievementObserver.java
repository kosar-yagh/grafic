
package com.Knight.model;

public interface AchievementObserver {
    void onAchievementUnlocked(String title);
}
