package com.Knight.model;

import com.badlogic.gdx.math.Rectangle;
import com.badlogic.gdx.math.Vector2;

public class CrystalCrawlerModel {
    public enum State { WALKING, DYING, DEAD }

    public Vector2 position;
    public Vector2 velocity;
    public Rectangle bounds;

    public State currentState;
    public float stateTime;
    public boolean facingLeft;
    public float damageCooldown;

    public int hp = 15; //  اضافه شدن مقدار سلامتی

    public CrystalCrawlerModel(float x, float y) {
        this.position = new Vector2(x, y);
        this.velocity = new Vector2(0, 0);
        this.bounds = new Rectangle(x, y, 40, 25);

        this.currentState = State.WALKING;
        this.stateTime = 0;
        this.facingLeft = true;
        this.damageCooldown = 0;
    }
}
