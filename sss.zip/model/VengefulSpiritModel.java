package com.Knight.model;
import com.badlogic.gdx.math.Rectangle;
import java.util.HashSet;

public class VengefulSpiritModel {
    public float x, y;
    public float speed = 600f; // سرعت ثابت و بالا (تحت تاثیر جاذبه نیست)
    public boolean facingRight;
    public Rectangle bounds;
    public boolean active = true;
    public float stateTime = 0;
    public HashSet<Object> hitEnemies = new HashSet<>(); // برای اینکه به هر دشمن فقط یک‌بار دمیج بزند

    public VengefulSpiritModel(float x, float y, boolean facingRight) {
        this.x = facingRight ? x + 20 : x - 80;
        this.y = y + 10;
        this.facingRight = facingRight;
        this.bounds = new Rectangle(this.x, this.y, 80, 45); // سایز پرتابه
    }

    public void update(float delta) {
        stateTime += delta;
        x += (facingRight ? speed : -speed) * delta;
        bounds.setPosition(x, y);
    }
}
