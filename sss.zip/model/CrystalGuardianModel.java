package com.Knight.model;

import com.badlogic.gdx.math.Rectangle;
import com.badlogic.gdx.math.Vector2;

public class CrystalGuardianModel {
    public enum State { IDLE, SHOOTING, ENRAGED, DEAD }

    public Vector2 position;
    public Vector2 velocity;
    public Rectangle bounds;
    public Rectangle visionZone;

    public State currentState;
    public float stateTime;
    public boolean facingLeft;

    public float enragedTimer;
    public float shootTimer;
    public float damageCooldown;

    public Rectangle laserBounds;
    public boolean isLaserActive;

    public int hp = 40; //
    // اضافه شدن مقدار سلامتی

    public CrystalGuardianModel(float x, float y, float visionW, float visionH) {
        this.position = new Vector2(x, y);
        this.velocity = new Vector2(0, 0);
        this.bounds = new Rectangle(x, y, 55, 65);
        this.visionZone = new Rectangle(x - visionW, y, visionW, visionH);
        this.laserBounds = new Rectangle(0, 0, 0, 0);

        this.currentState = State.IDLE;
        this.stateTime = 0;
        this.facingLeft = true;
        this.isLaserActive = false;
        this.damageCooldown = 0;
    }
}
