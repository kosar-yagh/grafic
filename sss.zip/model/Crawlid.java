package com.Knight.model;

import com.badlogic.gdx.math.Rectangle;
import com.badlogic.gdx.math.Vector2;
import com.badlogic.gdx.utils.Array;

public class Crawlid {
    public enum State { WALKING, TURNING, DEATH_LAND, DEATH_AIR }
    public State currentState = State.WALKING;

    public Vector2 position;
    public Vector2 velocity;
    public Rectangle bounds;

    public boolean movingLeft = true; // این جهت اصلی حرکت است
    public boolean isDead = false;
    public float stateTime = 0;
    public boolean isOnGround = false;

    private final float SPEED = 40f;
    private final float GRAVITY = -600f;
    private final float TURN_DURATION = 0.3f;

    public static final float WIDTH = 38f;
    public static final float HEIGHT = 24f;

    public Crawlid(float x, float y) {
        this.position = new Vector2(x, y);
        this.velocity = new Vector2(-SPEED, 0);
        this.bounds = new Rectangle(x, y, WIDTH, HEIGHT);
    }

    public void die() {
        if (isDead) return;
        isDead = true;
        currentState = State.DEATH_LAND;
        velocity.set(0, 0);
    }

    public void update(float delta, Array<SolidBlock> solidBlocks) {
        if (isDead) return;
        stateTime += delta;

        // اعمال جاذبه
        velocity.y += GRAVITY * delta;
        position.y += velocity.y * delta;
        bounds.setPosition(position.x, position.y);

        isOnGround = false;
        for (SolidBlock block : solidBlocks) {
            if (!block.isDeadly && bounds.overlaps(block.bounds)) {
                if (velocity.y < 0) {
                    position.y = block.bounds.y + block.bounds.height;
                    velocity.y = 0;
                    isOnGround = true;
                }
            }
        }

        // منطق چرخش قبل از پرتگاه و دیوار
        if (currentState == State.WALKING) {
            velocity.x = movingLeft ? -SPEED : SPEED;

            // چک کردن وجود زمین در جلو (برای جلوگیری از افتادن در دره)
            float checkX = movingLeft ? position.x - 5 : position.x + WIDTH + 5;
            boolean hasGroundAhead = false;
            for (SolidBlock block : solidBlocks) {
                if (!block.isDeadly && block.bounds.contains(checkX, position.y - 2)) {
                    hasGroundAhead = true;
                    break;
                }
            }

            // چک کردن دیوار
            boolean hitWall = false;
            Rectangle nextBounds = new Rectangle(position.x + (velocity.x * delta), position.y, WIDTH, HEIGHT);
            for (SolidBlock block : solidBlocks) {
                if (!block.isDeadly && nextBounds.overlaps(block.bounds)) {
                    hitWall = true;
                    break;
                }
            }

            if (hitWall || !hasGroundAhead) {
                currentState = State.TURNING;
                stateTime = 0;
            } else {
                position.x += velocity.x * delta;
            }
        }
        else if (currentState == State.TURNING) {
            if (stateTime >= TURN_DURATION) {
                movingLeft = !movingLeft; // تغییر جهت واقعی
                currentState = State.WALKING;
            }
        }

        bounds.setPosition(position.x, position.y);
    }
}
