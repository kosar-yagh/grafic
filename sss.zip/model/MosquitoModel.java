package com.Knight.model;

import com.badlogic.gdx.math.Rectangle;
import com.badlogic.gdx.math.Vector2;

public class MosquitoModel {
    //  وضعیت TURNING اضافه شد
    public enum State { IDLE, TURNING, ANTICIPATE, ATTACKING, DYING, DEAD }

    public State currentState = State.IDLE;
    public Vector2 position;
    public Vector2 velocity = new Vector2(0, 0);
    public Rectangle bounds;
    public Rectangle aggroZone;
    public float stateTime = 0;
    public boolean isDead = false;

    //  متغیر جدید برای ثبت جهت نگاه پشه
    public boolean facingLeft = true;

    public Vector2 dashDirection = new Vector2();

    public int hp = 10;

    public MosquitoModel(float x, float y, Rectangle aggroZone) {
        this.position = new Vector2(x, y);
        this.bounds = new Rectangle(x, y, 32, 32);
        this.aggroZone = aggroZone;
    }

    public void die() {
        if (!isDead) {
            isDead = true;
            currentState = State.DYING;
            stateTime = 0;
        }
    }
}
