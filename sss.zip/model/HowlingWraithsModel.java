package com.Knight.model;
import com.badlogic.gdx.math.Rectangle;

public class HowlingWraithsModel {
    public float x, y;
    public Rectangle bounds;
    public boolean active = true;
    public float stateTime = 0;
    public int ticks = 0;
    public float tickTimer = 0.15f; // آماده برای اولین تیک بلافاصله پس از شلیک

    public HowlingWraithsModel(float x, float y) {
        this.x = x - 30; // مرکز انفجار دقیقا روی شوالیه
        this.y = y + 40; // هیت‌باکس رو به بالا
        this.bounds = new Rectangle(this.x, this.y, 110, 160); // کادر دمیج‌دهی
    }

    public void update(float delta) {
        stateTime += delta;
        tickTimer += delta;
        if (stateTime > 0.6f) { // کل انیمیشن جادو 0.6 ثانیه طول می‌کشد
            active = false;
        }
    }
}
