package com.Knight.model;

public class SaveData {
    public float heroX;
    public float heroY;
    public int currentHealth;
    public String mapPath;
    // می‌توانید موارد دیگری مثل bossDefeated یا تعداد روح‌ها را هم اینجا اضافه کنید
}
