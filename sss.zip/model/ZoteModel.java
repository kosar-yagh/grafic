package com.Knight.model;

import com.badlogic.gdx.math.Rectangle;
import com.badlogic.gdx.math.Vector2;

public class ZoteModel {

    public enum State { IDLE, TALKING, FALLING, GET_UP, TURN, ATTACK, ROLL }

    public Vector2 position;
    public Vector2 velocity;
    public Rectangle bounds;

    public State currentState;
    public float stateTime;
    public boolean facingLeft;


    public boolean showDialogue;
    public int dialogueIndex;
    public float dialogueTimer;


    public float damageCooldown;

    public ZoteModel(float x, float y) {
        this.position = new Vector2(x, y);
        this.velocity = new Vector2(0, 0);
        this.bounds = new Rectangle(x, y, 40, 50); // سایز تقریبی زوت

        this.currentState = State.IDLE;
        this.stateTime = 0;
        this.facingLeft = true;
        this.showDialogue = false;
        this.dialogueIndex = 0;
        this.dialogueTimer = 0;
        this.damageCooldown = 0;
    }
}
