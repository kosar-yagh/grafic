package com.Knight.model;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Input;
import com.badlogic.gdx.math.Rectangle;
import com.badlogic.gdx.math.Vector2;
import com.badlogic.gdx.utils.Array;
import com.Knight.view.AnimationType;

public class Hero {
    public Vector2 position;
    public Vector2 velocity;
    public boolean isOnGround = false;
    public boolean movingLeft = false, movingRight = false;
    public boolean facingRight = true;
    //  سیستم سلامت و روح
    public int maxHealth = 7;
    public int currentHealth = 4;
    public int soul = 0;
    public int maxSoul = 99;

    //  متغیرهای سیستم تمرکز (Focus)
    public boolean isFocusing = false;
    public float focusTimer = 0f;
    public float stateTime = 0;
    public AnimationType currentAnimation = AnimationType.HOLLOW_KNIGHT_IDLE;
    public Rectangle bounds;

    private final float initialX, initialY;
    private float lastSafeX, lastSafeY;

    // متغیرهای پرش
    private int jumpCount = 0;
    public boolean isDoubleJumping = false;

    // متغیرهای حمله
    public boolean isAttacking = false;
    public float attackTimer = 0f;
    public final float ATTACK_DURATION = 0.25f;
    public Rectangle attackBounds = new Rectangle();

    // متغیرهای مکانیزم دَش (Dash)
    public boolean isDashing = false;
    public float dashTimer = 0f;
    public final float DASH_DURATION = 0.2f;
    public float dashCooldown = 0f;
    public final float DASH_COOLDOWN_TIME = 0.8f;


    public Hero(float x, float y) {
        position = new Vector2(x, y);
        velocity = new Vector2(0, 0);
        this.initialX = x;
        this.initialY = y;
        this.lastSafeX = x;
        this.lastSafeY = y;
        bounds = new Rectangle(x + 6, y, 20, 25);
    }

    public void attack() {
        if (!isAttacking) {
            isAttacking = true;
            attackTimer = 0f;
            stateTime = 0f;
        }
    }

    public void dash() {
        if (!isDashing && dashCooldown <= 0) {
            isDashing = true;
            dashTimer = DASH_DURATION;
            dashCooldown = DASH_COOLDOWN_TIME;
            stateTime = 0f;
            velocity.y = 0;
        }
    }

    public void jump() {
        if (isOnGround) {
            velocity.y = 420;
            isOnGround = false;
            jumpCount = 1;
            isDoubleJumping = false;
        } else if (jumpCount == 1) {
            velocity.y = 500;
            jumpCount = 2;
            isDoubleJumping = true;
            stateTime = 0;
        }
    }

    public void takeDamage(String reason, Array<SolidBlock> solidBlocks) {
        currentHealth--;
        System.out.println(" Knight took damage! Reason: [" + reason + "] | Current health: " + currentHealth);

        if (currentHealth <= 0) {
            currentHealth = maxHealth;
            position.set(initialX, initialY + 60f);
        } else {
            float targetX = lastSafeX;
            float targetY = lastSafeY;
            float closestXAfterPit = Float.MAX_VALUE;

            for (SolidBlock block : solidBlocks) {
                if (!block.isDeadly) {
                    if (block.bounds.x > position.x && block.bounds.x < closestXAfterPit) {
                        closestXAfterPit = block.bounds.x;
                        targetX = block.bounds.x + 4f;
                        targetY = block.bounds.y + block.bounds.height + 2f;
                    }
                }
            }
            position.set(targetX, targetY);
        }

        velocity.set(0, 0);
        bounds.setPosition(position.x + 6, position.y);
    }

    public void update(float delta, Array<SolidBlock> solidBlocks) {

        //  سیستم خواندن مستقیم سخت‌افزار (ضد باگ قطعی)

        movingLeft = Gdx.input.isKeyPressed(Input.Keys.LEFT) || Gdx.input.isKeyPressed(Input.Keys.A);
        movingRight = Gdx.input.isKeyPressed(Input.Keys.RIGHT) || Gdx.input.isKeyPressed(Input.Keys.D);

        // پرش
        if (Gdx.input.isKeyJustPressed(Input.Keys.Z) || Gdx.input.isKeyJustPressed(Input.Keys.SPACE) || Gdx.input.isKeyJustPressed(Input.Keys.UP) || Gdx.input.isKeyJustPressed(Input.Keys.W)) {
            jump();
        }

        // حمله
        if (Gdx.input.isKeyJustPressed(Input.Keys.X) || Gdx.input.isKeyJustPressed(Input.Keys.J)) {
            attack();
        }

        // دش
        if (Gdx.input.isKeyJustPressed(Input.Keys.C) || Gdx.input.isKeyJustPressed(Input.Keys.K)) {
            dash();
        }

        // ۱. آپدیت تایمرهای دَش و حمله
        if (dashCooldown > 0) dashCooldown -= delta;

        if (isAttacking) {
            attackTimer += delta;
            float hitboxWidth = 25f;
            float hitboxHeight = 24f;
            float hitboxX = !facingRight ? this.position.x - hitboxWidth : this.position.x + 32f;
            float hitboxY = this.position.y + 4f;
            attackBounds.set(hitboxX, hitboxY, hitboxWidth, hitboxHeight);

            if (attackTimer >= ATTACK_DURATION) {
                isAttacking = false;
            }
        }

        // ۲. تنظیم جهت نگاه
        if (!isDashing) {
            if (movingLeft) facingRight = false;
            else if (movingRight) facingRight = true;
        }

        if (isOnGround && (movingLeft || movingRight)) {
            stateTime += delta * (Math.abs(velocity.x) / 150f);
        } else {
            stateTime += delta;
        }

        // ۳. اعمال فیزیک
        float baseWalkSpeed = 150f;
        float dashSpeed = 600f;

        if (isDashing) {
            dashTimer -= delta;
            velocity.y = 0;
            velocity.x = facingRight ? dashSpeed : -dashSpeed;

            if (dashTimer <= 0) {
                isDashing = false;
            }
        } else {
            // منطق پرش پویا (تغییر جاذبه بر اساس نگه داشتن کلید)
            float currentGravity = 1000f;
            boolean jumpHeld = Gdx.input.isKeyPressed(Input.Keys.Z) || Gdx.input.isKeyPressed(Input.Keys.SPACE) || Gdx.input.isKeyPressed(Input.Keys.UP) || Gdx.input.isKeyPressed(Input.Keys.W);

            if (!jumpHeld && velocity.y > 0) {
                currentGravity = 3000f; // اگر کلید رها شود، سریع‌تر سقوط می‌کند
            }

            velocity.y -= currentGravity * delta;

            float maxRunSpeed = 280f;
            float runAcceleration = 180f;
            float friction = 1200f;

            if (movingLeft) {
                if (velocity.x > -baseWalkSpeed) velocity.x = -baseWalkSpeed;
                velocity.x -= runAcceleration * delta;
                if (velocity.x < -maxRunSpeed) velocity.x = -maxRunSpeed;
            } else if (movingRight) {
                if (velocity.x < baseWalkSpeed) velocity.x = baseWalkSpeed;
                velocity.x += runAcceleration * delta;
                if (velocity.x > maxRunSpeed) velocity.x = maxRunSpeed;
            } else {
                if (velocity.x > 0) {
                    velocity.x -= friction * delta;
                    if (velocity.x < 0) velocity.x = 0;
                } else if (velocity.x < 0) {
                    velocity.x += friction * delta;
                    if (velocity.x > 0) velocity.x = 0;
                }
            }
        }

        // ۴. برخورد در محور Y
        position.y += velocity.y * delta;
        bounds.setPosition(position.x + 6, position.y);
        isOnGround = false;

        for (SolidBlock block : solidBlocks) {
            if (bounds.overlaps(block.bounds)) {
                if (block.isDeadly) {
                    takeDamage("Hit Deadly Block on Y axis", solidBlocks);
                    break;
                }

                if (velocity.y < 0) {
                    position.y = block.bounds.y + block.bounds.height;
                    velocity.y = 0;
                    isOnGround = true;
                    jumpCount = 0;
                    isDoubleJumping = false;
                } else if (velocity.y > 0) {
                    if (block.bounds.y > position.y) {
                        position.y = block.bounds.y - bounds.height;
                        velocity.y = 0;
                    }
                }
                bounds.setPosition(position.x + 6, position.y);
            }
        }

        if (isOnGround) {
            lastSafeX = position.x;
            lastSafeY = position.y + 2f;
        }

        // ۵. برخورد در محور X
        position.x += velocity.x * delta;
        bounds.setPosition(position.x + 6, position.y);

        for (SolidBlock block : solidBlocks) {
            if (bounds.overlaps(block.bounds)) {
                if (block.isDeadly) {
                    takeDamage("Hit Deadly Block on X axis", solidBlocks);
                    break;
                }

                if (velocity.x > 0) {
                    position.x = block.bounds.x - bounds.width - 6;
                } else if (velocity.x < 0) {
                    position.x = block.bounds.x + block.bounds.width - 6;
                }
                velocity.x = 0;

                if (isDashing) isDashing = false;

                bounds.setPosition(position.x + 6, position.y);
            }
        }

        // ۶. ماشین وضعیت انیمیشن‌ها
        if (isDashing) {
            currentAnimation = AnimationType.HOLLOW_KNIGHT_DASH;
        } else if (isAttacking) {
            currentAnimation = AnimationType.HOLLOW_KNIGHT_ATTACK;
        } else if (isDoubleJumping && !isOnGround) {
            currentAnimation = AnimationType.HOLLOW_KNIGHT_DOUBLE_JUMP;
        } else if (!isOnGround) {
            currentAnimation = AnimationType.HOLLOW_KNIGHT_JUMP;
        } else {
            if (movingLeft || movingRight) {
                currentAnimation = AnimationType.HOLLOW_KNIGHT_WALK;
            } else {
                currentAnimation = AnimationType.HOLLOW_KNIGHT_IDLE;
            }
        }

        if (position.y < -50f) {
            takeDamage("Fell out of map (Y < -50)", solidBlocks);
        }
    }
}
