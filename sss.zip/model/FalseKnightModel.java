package com.Knight.model;

import com.badlogic.gdx.math.Rectangle;
import com.badlogic.gdx.math.Vector2;

public class FalseKnightModel {
    public enum State {
        IDLE,           // ۱. حالت عادی
        MACE_SLAM,      // ۲. کوبیدن گرز
        CHARGE_RUN,     // ۳. دویدن هجومی
        OFFENSIVE_LEAP, // ۴. پرش هجومی
        DEFENSIVE_LEAP, // ۵. پرش دفاعی
        POWER_SLAM,     // ۶. کوبیدن قدرتی گرز (موج) - فاز دوم
        STUN_RECOVER,   // ۷. بلند شدن از حالت گیجی
        JUMP_ATTACK,    // ۸. پرش و حمله همزمان
        STUNNED,        // ۹. گیج شدن (فاز دوم و خروج مگوت)
        DEAD            // ۱۰. مرگ و افتادن جنازه روی زمین
    }

    public State currentState = State.IDLE;
    public State lastState = State.IDLE;

    public Vector2 position;
    public Vector2 velocity;
    public Rectangle bounds;
    public Rectangle maggotHitbox;

    public float stateTime = 0;
    public float actionTimer = 0;

    public int maxHp = 60;
    public int currentHp;

    public float damageTimer = 0;
    public int recentDamageTaken = 0;

    public boolean triggerCameraShake = false;
    public boolean facingLeft = true;
    public boolean isPhaseTwo = false;

    // متغیرهای جدید برای محدود کردن منطقه (ArenaLogic)
    public float arenaLeftLimit;
    public float arenaRightLimit;
    public float floorY = 100f; // سطح زمین باس‌فایت

    public FalseKnightModel(float x, float y) {
        position = new Vector2(x, y);
        velocity = new Vector2(0, 0);
        bounds = new Rectangle(x, y, 150, 150);
        maggotHitbox = new Rectangle(0, 0, 30, 30);
        currentHp = maxHp;
    }

    public void setArenaLimits(float left, float right) {
        this.arenaLeftLimit = left;
        this.arenaRightLimit = right;
    }
}
