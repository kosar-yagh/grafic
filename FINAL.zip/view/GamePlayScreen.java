package com.Knight.view;
import com.Knight.view.GameSettings;
import com.badlogic.gdx.Input;
import com.badlogic.gdx.InputMultiplexer;
import com.badlogic.gdx.graphics.glutils.ShapeRenderer;
import com.badlogic.gdx.scenes.scene2d.Stage;
import com.badlogic.gdx.scenes.scene2d.ui.Skin;
import com.badlogic.gdx.scenes.scene2d.ui.Table;
import com.badlogic.gdx.scenes.scene2d.ui.TextButton;
import com.badlogic.gdx.scenes.scene2d.utils.ClickListener;
import com.badlogic.gdx.scenes.scene2d.InputEvent;
import com.Knight.controller.*;
import com.Knight.model.*;
import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.ScreenAdapter;
import com.badlogic.gdx.audio.Sound;
import com.badlogic.gdx.graphics.GL20;
import com.badlogic.gdx.graphics.OrthographicCamera;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.BitmapFont;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.graphics.g2d.TextureRegion;
import com.badlogic.gdx.graphics.g2d.Animation;
import com.badlogic.gdx.maps.MapLayer;
import com.badlogic.gdx.maps.MapObject;
import com.badlogic.gdx.maps.objects.RectangleMapObject;
import com.badlogic.gdx.maps.tiled.TiledMap;
import com.badlogic.gdx.maps.tiled.renderers.OrthogonalTiledMapRenderer;
import com.badlogic.gdx.math.MathUtils;
import com.badlogic.gdx.math.Rectangle;
import com.badlogic.gdx.utils.Array;
import com.badlogic.gdx.utils.viewport.FitViewport;

import static com.Knight.model.Crawlid.State.TURNING;

public class GamePlayScreen extends ScreenAdapter {
    private FalseKnightModel falseKnight;
    private FalseKnightController fkController;
    private Animation<TextureRegion> fkIdleAnim, fkMaceSlamAnim, fkChargeRunAnim, fkJumpAnim, fkPowerSlamAnim, fkStunnedAnim;
    private Animation<TextureRegion> fkStunRecoverAnim, fkDeathHitAnim, fkDeathLandAnim, fkRunAnticAnim, fkAttackAnticAnim;

    //  متغیرهای جادوها
    private Array<VengefulSpiritModel> vengefulSpirits = new Array<>();
    private Array<HowlingWraithsModel> howlingWraiths = new Array<>();
    private Texture vsTex, hwTex;
    private Animation<TextureRegion> vsAnim, hwAnim;
    private float castLockTimer = 0f;

    private final String mapPath;
    private TiledMap map;
    private OrthographicCamera camera;
    private OrthogonalTiledMapRenderer mapRenderer;
    private FitViewport viewport;
    private SpriteBatch batch;
    private Array<Crawlid> crawlids;
    private TiledMapHelper mapHelper;
    private Array<SolidBlock> allCollisionBlocks;

    private Hero hero;
    private GameProcessor gameProcessor;
    private CombatController combatController;

    private Array<HuskHornheadModel> hornheads;
    private HuskHornheadController hornheadController;
    private boolean isGameOver = false;
    private boolean isGameWon = false;
    private int enemiesKilledCount = 0;
    private String endMessage = "";
    private float totalGameTime = 0f;
    private int deathCount = 0;
    private boolean winStatsInitialized = false;
    private int previousHeroHealth = 4;
    private Table winMenuTable;
    private boolean isPaused = false;
    private Stage uiStage;
    private Table pauseMenuTable;
    private Table hudTable;
    private Skin skin;
    private com.badlogic.gdx.graphics.glutils.ShapeRenderer shapeRenderer;
        private Rectangle enterRoomTrigger;
    private float roomX, roomY;
    private boolean hasRoomTarget = false;

    private Array<MosquitoModel> mosquitos;
    private MosquitoController mosquitoController;

    public Array<CrystalCrawlerModel> crystalCrawlers;
    public CrystalCrawlerController crawlerController;
    private float startX = 150f;
    private float startY = 400f;
    private OrthographicCamera hudCamera;
    private Texture hudContainer;
    private TextureRegion emptyMask, fullMask;

    private Texture crawlidWalkSheet;
    private Animation<TextureRegion> crawlidWalkAnimation;

    private Texture hhIdleTex, hhWalkTex, hhAnticipateTex, hhLungeTex, hhDeathTex, hhTurnTex;
    private Animation<TextureRegion> hhIdleAnim, hhWalkAnim, hhAnticipateAnim, hhLungeAnim, hhDeathAnim, hhTurnAnim;
    private Texture mosqFlyTex, mosqAnticipateTex, mosqAttackTex, mosqDyingTex, mosqDeadTex, mosqTurnTex;
    private Animation<TextureRegion> mosqFlyAnim, mosqAnticipateAnim, mosqAttackAnim, mosqDyingAnim, mosqDeadAnim, mosqTurnAnim;
    private Array<CrystalGuardianModel> guardians = new Array<>();
    private CrystalGuardianController guardianController = new CrystalGuardianController();
    private Texture fullMaskTex;
    private Texture emptyMaskTex;
    private ZoteModel zote;
    private ZoteController zoteController;
    private Sound zoteTalkSound;
    private Animation<TextureRegion> zoteIdleAnim, zoteTalkAnim, zoteFallAnim, zoteGetUpAnim, zoteTurnAnim, zoteAttackAnim;

    private Rectangle arenaTriggerBounds;
    private Rectangle ceilingGateBounds;
    private boolean isArenaLocked = false;
    private Texture spikesTexture;
    // 🌟 آرایه‌ای برای نگهداری هیت‌باکس‌های کریستال‌های خطرناک
    private com.badlogic.gdx.utils.Array<com.badlogic.gdx.math.Rectangle> dangerCrystals = new com.badlogic.gdx.utils.Array<>();
    private Animation<TextureRegion> heroIdleAnim, heroWalkAnim, heroJumpAnim, heroDoubleJumpAnim, heroDashAnim, heroAttackAnim, heroDeathAnim;
    private BitmapFont font;
    //  متغیرهای جدید برای ماسک‌ها (چون عکس شما به صورت شیت چند فریمی است)
    private Texture maskSheetTex;
    private TextureRegion fullMaskRegion;
    private TextureRegion emptyMaskRegion;
    private Texture cgIdleTex, cgShootTex, cgRunTex, cgDeathTex, cgLaserTex;
    private Animation<TextureRegion> cgIdleAnim, cgShootAnim, cgRunAnim, cgDeathAnim;
    private TextureRegion laserBeamRegion;
    //  متغیرهای ثبت آمار پایان بازی
    // جدول نمایش آمار پیروزی
    public Texture crawlerWalkTex, crawlerDeathAirTex, crawlerDeathLandTex;
    public Animation<TextureRegion> crawlerWalkAnim, crawlerDeathAirAnim, crawlerDeathLandAnim;

    public GamePlayScreen(String mapPath) {
        this.mapPath = mapPath;
    }

    @Override
    public void show() {
        GameAssetManager.loadAnimations();
        font = new BitmapFont();

        mapHelper = new TiledMapHelper();
        map = mapHelper.loadMap(mapPath);
        allCollisionBlocks = new Array<>();

        MapLayer arenaLogicLayer = map.getLayers().get("ArenaLogic");
        if (arenaLogicLayer != null) {
            for (MapObject object : arenaLogicLayer.getObjects()) {
                if (object instanceof RectangleMapObject) {
                    arenaTriggerBounds = ((RectangleMapObject) object).getRectangle();
                    break;
                }
            }
        }

        Array<Rectangle> triggerZones = new Array<>();
        if (map.getLayers().get("triggers") != null) {
            for (MapObject obj : map.getLayers().get("triggers").getObjects()) {
                if (obj instanceof RectangleMapObject) {
                    triggerZones.add(((RectangleMapObject) obj).getRectangle());
                }
            }
        }

        MapLayer gateLayer = map.getLayers().get("CeilingGate");
        if (gateLayer != null) {
            for (MapObject object : gateLayer.getObjects()) {
                if (object instanceof RectangleMapObject) {
                    if ("CeilingGate".equals(object.getName())) {
                        ceilingGateBounds = ((RectangleMapObject) object).getRectangle();
                    }
                }
            }
        }

        spikesTexture = new Texture(Gdx.files.internal("animations/mine_crystal_08.png"));

        //  لود کردن کریستال‌های خطرناک (تله‌ها)

        MapLayer dangerLayer = map.getLayers().get("dangercrystal");
        if (dangerLayer != null) {
            for (MapObject object : dangerLayer.getObjects()) {
                if (object instanceof RectangleMapObject) {
                    Rectangle rect = ((RectangleMapObject) object).getRectangle();
                    // ذخیره دقیق مختصات و ابعاد تله‌ها
                    dangerCrystals.add(new Rectangle(rect.x, rect.y, rect.width, rect.height));
                }
            }
            System.out.println("⚠️ تعداد " + dangerCrystals.size + " کریستال خطرناک لود شد.");
        }
        // لود کردن درها
        if (map.getLayers().get("Doors") != null) {
            for (MapObject obj : map.getLayers().get("Doors").getObjects()) {
                if (obj.getName() != null) {
                    String objName = obj.getName().trim();
                    if (objName.equalsIgnoreCase("Enter_Room")) {
                        if (obj instanceof RectangleMapObject) {
                            enterRoomTrigger = ((RectangleMapObject) obj).getRectangle();
                        }
                    }
                }
            }
        }

        Array<SolidBlock> walkingGrounds = mapHelper.getBlocksFromLayer("barkhorda", false);
        allCollisionBlocks.addAll(walkingGrounds);
        Array<SolidBlock> deadlyGrounds = mapHelper.getBlocksFromLayer("tamamzamin", true);
        allCollisionBlocks.addAll(deadlyGrounds);

        // لود کردن پشه‌ها
        mosquitos = new Array<>();
        mosquitoController = new MosquitoController();
        if (map.getLayers().get("Mosquito") != null) {
            for (MapObject obj : map.getLayers().get("Mosquito").getObjects()) {
                if ("Mosquito".equals(obj.getName())) {
                    float x = obj.getProperties().get("x", Float.class);
                    float y = obj.getProperties().get("y", Float.class);
                    Rectangle myZone = new Rectangle(x - 150, y - 100, 300, 200);
                    for (Rectangle zone : triggerZones) {
                        if (zone.contains(x + 16, y + 16)) {
                            myZone = zone;
                            break;
                        }
                    }
                    mosquitos.add(new MosquitoModel(x, y, myZone));
                }
            }
        }

        // لود کردن کریستال کراولرها
        crystalCrawlers = new Array<>();
        crawlerController = new CrystalCrawlerController();
        if(map.getLayers().get("Crystal Crawler")!=null){
            for (MapObject obj : map.getLayers().get("Crystal Crawler").getObjects()) {
                float x = obj.getProperties().get("x", Float.class);
                float y = obj.getProperties().get("y", Float.class);
                crystalCrawlers.add(new CrystalCrawlerModel(x, y));
                System.out.println("💎 Crystal Guardian با موفقیت پیدا و لود شد در مختصات: " + x + " , " + y);
            }
        }


        MapLayer guardianLayer = map.getLayers().get("Crystal Guardian");
        if (guardianLayer != null) {
            for (MapObject object : guardianLayer.getObjects()) {
                Object xProp = object.getProperties().get("x");
                Object yProp = object.getProperties().get("y");

                if (xProp != null && yProp != null) {
                    float x = Float.parseFloat(xProp.toString());
                    float y = Float.parseFloat(yProp.toString());


                    guardians.add(new CrystalGuardianModel(x, y, 400f, 60f));
                    System.out.println("💎 Crystal Guardian آماده نبرد در: " + x + " , " + y);
                }
            }
        }

        // لود Husk Hornhead
        hornheads = new Array<>();
        hornheadController = new HuskHornheadController();
        if (map.getLayers().get("Husk Hornhead") != null) {
            for (MapObject obj : map.getLayers().get("Husk Hornhead").getObjects()) {
                float x = obj.getProperties().get("x", Float.class);
                float y = obj.getProperties().get("y", Float.class);
                Rectangle myZone = new Rectangle(x - 200, y - 50, 400, 100);
                hornheads.add(new HuskHornheadModel(x, y, myZone));
            }
        }

        mapRenderer = new OrthogonalTiledMapRenderer(map, 1f);
        camera = new OrthographicCamera();
        viewport = new FitViewport(300f, 200f, camera);
        batch = new SpriteBatch();
        camera.zoom = 1.5f;


        float startX = 150f;
        float startY = 400f;
        if (map.getLayers().get("Knight") != null) {
            for (MapObject obj : map.getLayers().get("Knight").getObjects()) {
                if (obj.getName() != null) {
                    String objName = obj.getName().trim();
                    if (objName.equalsIgnoreCase("startKnight")) {
                        startX = obj.getProperties().get("x", Float.class);
                        startY = obj.getProperties().get("y", Float.class) + 150f;
                    } else if (objName.equalsIgnoreCase("insideRoom")) {
                        Object xObj = obj.getProperties().get("x");
                        Object yObj = obj.getProperties().get("y");
                        if (xObj != null && yObj != null) {
                            roomX = Float.parseFloat(xObj.toString());
                            roomY = Float.parseFloat(yObj.toString());
                            hasRoomTarget = true;
                        }
                    }
                }
            }
        }

        // لود فالس نایت
        MapLayer fkLayer = map.getLayers().get("baseFight");
        if (fkLayer != null) {
            for (MapObject object : fkLayer.getObjects()) {
                float x = object.getProperties().get("x", Float.class);
                float y = object.getProperties().get("y", Float.class);
                falseKnight = new FalseKnightModel(x, y);

                if (arenaTriggerBounds != null) {
                    falseKnight.setArenaLimits(arenaTriggerBounds.x, arenaTriggerBounds.x + arenaTriggerBounds.width);
                    falseKnight.floorY = arenaTriggerBounds.y;
                }
                break;
            }
        }

        crawlids = new Array<>();
        if (map.getLayers().get("Crawlid") != null) {
            for (MapObject obj : map.getLayers().get("Crawlid").getObjects()) {
                if ("Crawlid".equals(obj.getName())) {
                    float x = obj.getProperties().get("x", Float.class);
                    float y = obj.getProperties().get("y", Float.class);
                    crawlids.add(new Crawlid(x, y));
                }
            }
        }

        hudCamera = new OrthographicCamera(400f, 240f);
        hudCamera.position.set(200f, 120f, 0f);
        hudCamera.update();
        //for mask

        maskSheetTex = new Texture(Gdx.files.internal("animations/HealthRefill.png"));
        TextureRegion[][] tmpMasks = TextureRegion.split(maskSheetTex, maskSheetTex.getWidth() / 5, maskSheetTex.getHeight());


        emptyMaskRegion = tmpMasks[0][0];

        fullMaskRegion = tmpMasks[0][4];


        hudContainer = new Texture(Gdx.files.internal("animations/HealthBar_005.png"));
        crawlidWalkSheet = new Texture(Gdx.files.internal("animations/Walk.png"));
        crawlidWalkAnimation = new Animation<>(0.15f, TextureRegion.split(crawlidWalkSheet, crawlidWalkSheet.getWidth() / 4, crawlidWalkSheet.getHeight())[0]);

        //جادو ها

        try {
            vsTex = new Texture(Gdx.files.internal("animations/ShadowBall.png"));
            vsAnim = new Animation<>(0.1f, TextureRegion.split(vsTex, vsTex.getWidth() / 6, vsTex.getHeight())[0]);
        } catch (Exception e) { vsAnim = heroIdleAnim; } // موقتی اگر عکس نبود
        try {
            hwTex = new Texture(Gdx.files.internal("animations/Blast.png"));
            hwAnim = new Animation<>(0.1f, new TextureRegion[]{new TextureRegion(hwTex)});
        } catch (Exception e) { hwAnim = heroIdleAnim; }

        hero = new Hero(startX, startY);
        combatController = new CombatController(hero);
        gameProcessor = new GameProcessor(hero);

        // انیمیشن‌های شوالیه
        Texture heroIdleTex = new Texture(Gdx.files.internal(AnimationType.HOLLOW_KNIGHT_IDLE.path));
        heroIdleAnim = new Animation<>(0.15f, TextureRegion.split(heroIdleTex, heroIdleTex.getWidth() / AnimationType.HOLLOW_KNIGHT_IDLE.colCount, heroIdleTex.getHeight())[0]);

        Texture heroWalkTex = new Texture(Gdx.files.internal(AnimationType.HOLLOW_KNIGHT_WALK.path));
        heroWalkAnim = new Animation<>(0.1f, TextureRegion.split(heroWalkTex, heroWalkTex.getWidth() / AnimationType.HOLLOW_KNIGHT_WALK.colCount, heroWalkTex.getHeight())[0]);

        Texture heroAttackTex = new Texture(Gdx.files.internal(AnimationType.HOLLOW_KNIGHT_ATTACK.path));
        heroAttackAnim = new Animation<>(0.05f, TextureRegion.split(heroAttackTex, heroAttackTex.getWidth() / AnimationType.HOLLOW_KNIGHT_ATTACK.colCount, heroAttackTex.getHeight())[0]);

        Texture heroJumpTex = new Texture(Gdx.files.internal(AnimationType.HOLLOW_KNIGHT_JUMP.path));
        heroJumpAnim = new Animation<>(0.1f, TextureRegion.split(heroJumpTex, heroJumpTex.getWidth() / AnimationType.HOLLOW_KNIGHT_JUMP.colCount, heroJumpTex.getHeight())[0]);

        Texture heroDoubleJumpTex = new Texture(Gdx.files.internal(AnimationType.HOLLOW_KNIGHT_DOUBLE_JUMP.path));
        heroDoubleJumpAnim = new Animation<>(0.08f, TextureRegion.split(heroDoubleJumpTex, heroDoubleJumpTex.getWidth() / AnimationType.HOLLOW_KNIGHT_DOUBLE_JUMP.colCount, heroDoubleJumpTex.getHeight())[0]);

        try {
            Texture heroDashTex = new Texture(Gdx.files.internal(AnimationType.HOLLOW_KNIGHT_DASH.path));
            heroDashAnim = new Animation<>(0.05f, TextureRegion.split(heroDashTex, heroDashTex.getWidth() / AnimationType.HOLLOW_KNIGHT_DASH.colCount, heroDashTex.getHeight())[0]);
        } catch (Exception e) {
            heroDashAnim = heroWalkAnim;
        }

        camera.position.set(hero.position.x, hero.position.y, 0);
        camera.update();

        // انیمیشن‌های Crystal Crawler
        crawlerWalkTex = new Texture(Gdx.files.internal("animations/Crystal Crawler/Walk.png"));
        crawlerWalkAnim = new Animation<>(0.15f, TextureRegion.split(crawlerWalkTex, crawlerWalkTex.getWidth() / 4, crawlerWalkTex.getHeight())[0]);

        crawlerDeathAirTex = new Texture(Gdx.files.internal("animations/Crystal Crawler/Death Air.png"));
        crawlerDeathAirAnim = new Animation<>(0.1f, TextureRegion.split(crawlerDeathAirTex, crawlerDeathAirTex.getWidth() / 4, crawlerDeathAirTex.getHeight())[0]);

        crawlerDeathLandTex = new Texture(Gdx.files.internal("animations/Crystal Crawler/Death Land.png"));
        crawlerDeathLandAnim = new Animation<>(0.15f, TextureRegion.split(crawlerDeathLandTex, crawlerDeathLandTex.getWidth() / 3, crawlerDeathLandTex.getHeight())[0]);

        // انیمیشن‌های Husk Hornhead
        hhIdleTex = new Texture(Gdx.files.internal("animations/husk/Idle.png"));
        hhIdleAnim = new Animation<>(0.15f, TextureRegion.split(hhIdleTex, hhIdleTex.getWidth() / 6, hhIdleTex.getHeight())[0]);

        hhWalkTex = new Texture(Gdx.files.internal("animations/husk/Walk.png"));
        hhWalkAnim = new Animation<>(0.12f, TextureRegion.split(hhWalkTex, hhWalkTex.getWidth() / 7, hhWalkTex.getHeight())[0]);

        hhAnticipateTex = new Texture(Gdx.files.internal("animations/husk/Attack Anticipate.png"));
        hhAnticipateAnim = new Animation<>(0.1f, TextureRegion.split(hhAnticipateTex, hhAnticipateTex.getWidth() / 5, hhAnticipateTex.getHeight())[0]);

        hhLungeTex = new Texture(Gdx.files.internal("animations/husk/Attack Lunge.png"));
        hhLungeAnim = new Animation<>(0.06f, TextureRegion.split(hhLungeTex, hhLungeTex.getWidth() / 12, hhLungeTex.getHeight())[0]);

        hhDeathTex = new Texture(Gdx.files.internal("animations/husk/Death Land.png"));
        hhDeathAnim = new Animation<>(0.12f, TextureRegion.split(hhDeathTex, hhDeathTex.getWidth() / 8, hhDeathTex.getHeight())[0]);

        hhTurnTex = new Texture(Gdx.files.internal("animations/husk/Turn.png"));
        hhTurnAnim = new Animation<>(0.1f, TextureRegion.split(hhTurnTex, hhTurnTex.getWidth() / 2, hhTurnTex.getHeight())[0]);
        // انیمیشن‌های Zote
        zoteController = new ZoteController();
        zoteTalkSound = Gdx.audio.newSound(Gdx.files.internal("audio/zote_talk.ogg"));

        Texture idleTex = new Texture("animations/Zote/Idle.png");
        zoteIdleAnim = new Animation<>(0.15f, TextureRegion.split(idleTex, idleTex.getWidth() / 5, idleTex.getHeight())[0]);
        Texture talkTex = new Texture("animations/Zote/Talk.png");
        zoteTalkAnim = new Animation<>(0.15f, TextureRegion.split(talkTex, talkTex.getWidth() / 5, talkTex.getHeight())[0]);
        Texture fallTex = new Texture("animations/Zote/Fall.png");
        zoteFallAnim = new Animation<>(0.1f, TextureRegion.split(fallTex, fallTex.getWidth() / 5, fallTex.getHeight())[0]);
        Texture getUpTex = new Texture("animations/Zote/Get Up.png");
        zoteGetUpAnim = new Animation<>(0.15f, TextureRegion.split(getUpTex, getUpTex.getWidth() / 4, getUpTex.getHeight())[0]);
        Texture turnTex = new Texture("animations/Zote/Turn.png");
        zoteTurnAnim = new Animation<>(0.1f, TextureRegion.split(turnTex, turnTex.getWidth() / 2, turnTex.getHeight())[0]);
        Texture attackTex = new Texture("animations/Zote/Attack.png");
        zoteAttackAnim = new Animation<>(0.1f, TextureRegion.split(attackTex, attackTex.getWidth() / 4, attackTex.getHeight())[0]);

        MapLayer zoteLayer = map.getLayers().get("Zote");
        if (zoteLayer != null) {
            for (MapObject object : zoteLayer.getObjects()) {
                float x = object.getProperties().get("x", Float.class);
                float y = object.getProperties().get("y", Float.class);
                zote = new ZoteModel(x, y);
                break;
            }
        }

        // انیمیشن‌های Crystal Guardian
        cgIdleTex = new Texture(Gdx.files.internal("animations/Crystal Guardian/Idle.png"));
        cgIdleAnim = new Animation<>(0.15f, TextureRegion.split(cgIdleTex, cgIdleTex.getWidth() / 5, cgIdleTex.getHeight())[0]);

        cgShootTex = new Texture(Gdx.files.internal("animations/Crystal Guardian/Shoot.png"));
        cgShootAnim = new Animation<>(0.13f, TextureRegion.split(cgShootTex, cgShootTex.getWidth() / 7, cgShootTex.getHeight())[0]);

        cgRunTex = new Texture(Gdx.files.internal("animations/Crystal Guardian/Run.png"));
        cgRunAnim = new Animation<>(0.1f, TextureRegion.split(cgRunTex, cgRunTex.getWidth() / 6, cgRunTex.getHeight())[0]);

        cgDeathTex = new Texture(Gdx.files.internal("animations/Crystal Guardian/Death Land.png"));
        cgDeathAnim = new Animation<>(0.15f, TextureRegion.split(cgDeathTex, cgDeathTex.getWidth() / 3, cgDeathTex.getHeight())[0]);

        cgLaserTex = new Texture(Gdx.files.internal("animations/Crystal Guardian/laster.png"));
        laserBeamRegion = new TextureRegion(cgLaserTex, 0, 0, 256, 35);

        // انیمیشن‌های پشه (Mosquito)
        mosqFlyTex = new Texture(Gdx.files.internal("animations/Idle.png"));
        mosqFlyAnim = new Animation<>(0.1f, TextureRegion.split(mosqFlyTex, mosqFlyTex.getWidth() / 9, mosqFlyTex.getHeight())[0]);
        mosqAnticipateTex = new Texture(Gdx.files.internal("animations/Attack Anticipate.png"));
        mosqAnticipateAnim = new Animation<>(0.1f, TextureRegion.split(mosqAnticipateTex, mosqAnticipateTex.getWidth() / 6, mosqAnticipateTex.getHeight())[0]);
        mosqAttackTex = new Texture(Gdx.files.internal("animations/Attack.png"));
        mosqAttackAnim = new Animation<>(0.08f, TextureRegion.split(mosqAttackTex, mosqAttackTex.getWidth() / 3, mosqAttackTex.getHeight())[0]);
        mosqDyingTex = new Texture(Gdx.files.internal("animations/Death Land.png"));
        mosqDyingAnim = new Animation<>(0.15f, TextureRegion.split(mosqDyingTex, mosqDyingTex.getWidth() / 2, mosqDyingTex.getHeight())[0]);
        mosqDeadTex = new Texture(Gdx.files.internal("animations/Death Air.png"));
        mosqDeadAnim = new Animation<>(0.2f, TextureRegion.split(mosqDeadTex, mosqDeadTex.getWidth() / 3, mosqDeadTex.getHeight())[0]);
        mosqTurnTex = new Texture(Gdx.files.internal("animations/Turn.png"));
        mosqTurnAnim = new Animation<>(0.1f, TextureRegion.split(mosqTurnTex, mosqTurnTex.getWidth() / 2, mosqTurnTex.getHeight())[0]);
        // انیمیشن‌های فالس نایت
        fkController = new FalseKnightController();
        Texture fkIdleTex = new Texture(Gdx.files.internal("animations/FalseKnight/Idle.png"));
        fkIdleAnim = new Animation<>(0.15f, TextureRegion.split(fkIdleTex, fkIdleTex.getWidth() / 5, fkIdleTex.getHeight())[0]);

        Texture fkAtkTex = new Texture(Gdx.files.internal("animations/FalseKnight/Attack Antic.png"));
        fkMaceSlamAnim = new Animation<>(0.1f, TextureRegion.split(fkAtkTex, fkAtkTex.getWidth() / 6, fkAtkTex.getHeight())[0]);

        Texture fkRunTex = new Texture(Gdx.files.internal("animations/FalseKnight/Run.png"));
        fkChargeRunAnim = new Animation<>(0.1f, TextureRegion.split(fkRunTex, fkRunTex.getWidth() / 5, fkRunTex.getHeight())[0]);

        Texture fkJumpTex = new Texture(Gdx.files.internal("animations/FalseKnight/Jump Attack.png"));
        TextureRegion[] jumpFrames = TextureRegion.split(fkJumpTex, fkJumpTex.getWidth() / 8, fkJumpTex.getHeight())[0];
        fkJumpAnim = new Animation<>(0.1f, jumpFrames);
        fkPowerSlamAnim = new Animation<>(0.1f, jumpFrames);

        Texture fkStunRecTex = new Texture(Gdx.files.internal("animations/FalseKnight/Stun Recover.png"));
        fkStunRecoverAnim = new Animation<>(0.15f, TextureRegion.split(fkStunRecTex, fkStunRecTex.getWidth() / 6, fkStunRecTex.getHeight())[0]);

        Texture fkStunTex = new Texture(Gdx.files.internal("animations/FalseKnight/Body.png"));
        fkStunnedAnim = new Animation<>(0.15f, TextureRegion.split(fkStunTex, fkStunTex.getWidth() / 5, fkStunTex.getHeight())[0]);

        Texture fkDeathLandTex = new Texture(Gdx.files.internal("animations/FalseKnight/DeathLand.png"));
        fkDeathLandAnim = new Animation<>(0.15f, TextureRegion.split(fkDeathLandTex, fkDeathLandTex.getWidth() / 11, fkDeathLandTex.getHeight())[0]);

        skin = new Skin(Gdx.files.internal("ui/uiskin.json"));
        uiStage = new Stage(new FitViewport(800, 480), batch);


        pauseMenuTable = new Table();
        pauseMenuTable.setFillParent(true);
        pauseMenuTable.center();

        TextButton continueBtn = new TextButton("Continue", skin);
        continueBtn.addListener(new ClickListener() {
            @Override
            public void clicked(InputEvent event, float x, float y) {
                togglePause();
            }
        });


        TextButton settingsBtn = new TextButton("Settings", skin);
        settingsBtn.addListener(new ClickListener() {
            @Override
            public void clicked(InputEvent event, float x, float y) {
                // انتقال به صفحه تنظیمات
                try {
                    com.badlogic.gdx.Game game = (com.badlogic.gdx.Game) Gdx.app.getApplicationListener();

                } catch (Exception e) {
                    System.out.println("Could not switch to settings screen");
                }
            }
        });


        TextButton saveQuitBtn = new TextButton("Save & Quit", skin);
        saveQuitBtn.addListener(new ClickListener() {
            @Override
            public void clicked(InputEvent event, float x, float y) {
                Gdx.app.exit(); // یا بازگشت به منوی اصلی بازی
            }
        });

        pauseMenuTable.add(continueBtn).width(250).height(60).pad(10).row();
        pauseMenuTable.add(settingsBtn).width(250).height(60).pad(10).row();
        pauseMenuTable.add(saveQuitBtn).width(250).height(60).pad(10).row();

        pauseMenuTable.setVisible(false);
        uiStage.addActor(pauseMenuTable);
        hudTable = new Table();
        hudTable.setFillParent(true);
        hudTable.top().right();

        TextButton menuBtn = new TextButton("Menu (ESC)", skin);
        menuBtn.addListener(new ClickListener() {
            @Override
            public void clicked(InputEvent event, float x, float y) {
                togglePause();
            }
        });

        hudTable.add(menuBtn).pad(20).width(150).height(50);
        uiStage.addActor(hudTable);

        InputMultiplexer multiplexer = new InputMultiplexer();
        multiplexer.addProcessor(gameProcessor);
        multiplexer.addProcessor(uiStage);
        Gdx.input.setInputProcessor(multiplexer);
        //  ساخت جدول صفحه پایان بازی
        winMenuTable = new Table();
        winMenuTable.setFillParent(true);
        winMenuTable.center();
        winMenuTable.setVisible(false);
        uiStage.addActor(winMenuTable);

    }

    private void togglePause() {
        isPaused = !isPaused;
        pauseMenuTable.setVisible(isPaused);
        hudTable.setVisible(!isPaused);
    }

    @Override
    public void render(float delta) {
        if (delta > 0.1f) delta = 0.016f;

        Gdx.gl.glClearColor(0.5f, 0.5f, 0.5f, 1);
        Gdx.gl.glClear(GL20.GL_COLOR_BUFFER_BIT);

        if (Gdx.input.isKeyJustPressed(Input.Keys.ESCAPE)) {
            togglePause();
        }

        if (!isPaused) {
            if (!isGameWon) {
                totalGameTime += delta;

                //  منطق جدید مرگ: زنده شدن در نقطه شروع به جای Game Over
                if (hero.currentHealth < previousHeroHealth) {
                    if (previousHeroHealth == 1) {
                        deathCount++;
                        hero.currentHealth = hero.maxHealth; // پر شدن کامل ماسک‌ها
                        hero.soul = 0; // خالی شدن روح
                        hero.position.set(startX, startY); // تلپورت به نقطه شروع
                        camera.position.set(startX, startY, 0); // انتقال دوربین
                    }
                }
                previousHeroHealth = hero.currentHealth;

                //  ۲. مکانیزم تمرکز (Focus) برای بازیابی سلامت
                // اگر کلید A نگه داشته شده، روح کافیه، خون پر نیست و در حال حمله نیستیم:
                if (Gdx.input.isKeyPressed(Input.Keys.A) && hero.soul >= 33 && hero.currentHealth < hero.maxHealth && !hero.isAttacking) {
                    hero.velocity.x = 0; // توقف کامل حرکت حین تمرکز
                    hero.isFocusing = true;
                    hero.focusTimer += delta;


                    if (hero.focusTimer >= 1.5f) {
                        hero.currentHealth++;
                        hero.soul -= 33;
                        hero.focusTimer = 0f; 
                        System.out.println("💖Health Restored! Current Health: " + hero.currentHealth);
                    }
                } else {
                    // اگر دستش رو برداشت یا وسط کار متوقف شد (روح کم نمیشه، خونی هم اضافه نمیشه)
                    hero.isFocusing = false;
                    hero.focusTimer = 0f;
                }

                // محاسبه تعداد دشمنان کشته شده
                enemiesKilledCount = 0;
                for (Crawlid c : crawlids) {
                    if (c.currentState == Crawlid.State.DEATH_LAND || c.currentState == Crawlid.State.DEATH_AIR)
                        enemiesKilledCount++;
                }
                for (MosquitoModel m : mosquitos) {
                    if (m.currentState == MosquitoModel.State.DEAD || m.currentState == MosquitoModel.State.DYING)
                        enemiesKilledCount++;
                }
                for (CrystalCrawlerModel cc : crystalCrawlers) {
                    if (cc.currentState == CrystalCrawlerModel.State.DEAD || cc.currentState == CrystalCrawlerModel.State.DYING)
                        enemiesKilledCount++;
                }
                for (CrystalGuardianModel cg : guardians) {
                    if (cg.currentState == CrystalGuardianModel.State.DEAD) enemiesKilledCount++;
                }
                for (HuskHornheadModel h : hornheads) {
                    if (h.currentState == HuskHornheadModel.State.DEAD) enemiesKilledCount++;
                }

                if (falseKnight != null) {
                    if (falseKnight.currentHp <= 0 && falseKnight.currentState != FalseKnightModel.State.DEAD) {
                        falseKnight.currentState = FalseKnightModel.State.DEAD;
                    }
                    if (falseKnight.currentState == FalseKnightModel.State.DEAD) {
                        isGameWon = true;
                        if (!winStatsInitialized) {
                            showEndGameScreen(true);
                            winStatsInitialized = true;
                            isPaused = true;
                        }
                    }
                }
            }
            if (castLockTimer > 0) {
                castLockTimer -= delta;
                hero.velocity.x = 0;
            }

            // ۲. شلیک Vengeful Spirit با فشردن دکمه F
            if (Gdx.input.isKeyJustPressed(Input.Keys.F) && hero.soul >= 33 && castLockTimer <= 0 && !hero.isFocusing) {
                hero.soul -= 33;
                castLockTimer = 0.35f;
                vengefulSpirits.add(new VengefulSpiritModel(hero.position.x, hero.position.y, hero.facingRight));
            }

            // ۳. انفجار Howling Wraiths با فشردن دکمه G
            if (Gdx.input.isKeyJustPressed(Input.Keys.G) && hero.soul >= 33 && castLockTimer <= 0 && !hero.isFocusing) {
                hero.soul -= 33;
                castLockTimer = 0.5f;
                howlingWraiths.add(new HowlingWraithsModel(hero.position.x, hero.position.y));
            }

            // ۴. آپدیت موقعیت جادوها و حذف پرتابه در صورت برخورد با دیوار
            for (int i = vengefulSpirits.size - 1; i >= 0; i--) {
                VengefulSpiritModel vs = vengefulSpirits.get(i);
                vs.update(delta);
                for (SolidBlock block : allCollisionBlocks) {
                    if (vs.bounds.overlaps(block.bounds)) {
                        vs.active = false;
                        break;
                    }
                }
                if (!vs.active) vengefulSpirits.removeIndex(i);
            }

            for (int i = howlingWraiths.size - 1; i >= 0; i--) {
                HowlingWraithsModel hw = howlingWraiths.get(i);
                hw.update(delta);
                if (!hw.active) howlingWraiths.removeIndex(i);
            }


            combatController.handleSpells(vengefulSpirits, howlingWraiths, crawlids, mosquitos, crystalCrawlers, guardians, hornheads, falseKnight, fkController);

            // ۶. ⚔️ آپدیت مبارزات عادی (شمشیر زدن و دمیج خوردن) - این خط باعث میشه دشمنا بمیرن!
            combatController.update(delta, crawlids, mosquitos, crystalCrawlers, guardians, hornheads);


            // ۸. حرکت هیرو (فقط وقتی جادو نمی‌زنه و تمرکز نمی‌کنه)
            if (!hero.isFocusing && castLockTimer <= 0) {
                hero.update(delta, allCollisionBlocks);
            } else {
                hero.velocity.y += -600f * delta;
                hero.position.y += hero.velocity.y * delta;
                hero.bounds.setPosition(hero.position.x, hero.position.y);
            }

            //  ۹. بررسی برخورد شوالیه با کریستال‌های خطرناک

            if (!hero.isFocusing && combatController != null && !combatController.isHeroInvincible()) {
                for (Rectangle dangerBounds : dangerCrystals) {
                    if (hero.bounds.overlaps(dangerBounds)) {
                        hero.currentHealth -= 1; // کم شدن یک ماسک
                        combatController.setHeroInvincible(true);
                        // فعال شدن چشمک‌زدن و آسیب‌ناپذیری ۱ ثانیه‌ای

                        //  یک پرتاب کوچیک به عقب و بالا تا تو کریستال گیر نکنه!
                        hero.velocity.y = 350f;
                        hero.velocity.x = hero.facingRight ? -250f : 250f;

                        System.out.println(" برخورد با کریستال تیز! جون فعلی: " + hero.currentHealth);
                        break; // خروج از حلقه تا تو یک فریم دو بار دمیج نخوره
                    }
                }
            }
            // ---> اینجا کدهای آپدیت دشمنای عادی قرار داره (مثلا حلقه آپدیت mosquitos)
                if (hasRoomTarget && enterRoomTrigger != null) {
                    if (hero.bounds.overlaps(enterRoomTrigger)) {
                        hero.position.set(roomX, roomY);
                        hero.bounds.setPosition(roomX + 6, roomY);
                        hero.velocity.set(0, 0);
                    }
                }
                for (CrystalCrawlerModel crawler : crystalCrawlers) {
                    crawlerController.update(delta, crawler, hero, allCollisionBlocks, combatController);
                }
                for (CrystalGuardianModel cg : guardians) {
                    guardianController.update(delta, cg, hero, allCollisionBlocks, combatController);
                }
                for (MosquitoModel m : mosquitos) {
                    mosquitoController.update(delta, m, hero, allCollisionBlocks);
                }
                for (HuskHornheadModel h : hornheads) {
                    hornheadController.update(delta, h, hero, allCollisionBlocks, combatController);
                }

                if (!isArenaLocked && arenaTriggerBounds != null && ceilingGateBounds != null) {
                    if (hero.bounds.overlaps(arenaTriggerBounds)) {
                        isArenaLocked = true;

                        // ۱. بستن سقف (همون دروازه بالایی)
                        SolidBlock ceilingBlock = new SolidBlock(ceilingGateBounds.x, ceilingGateBounds.y, ceilingGateBounds.width, ceilingGateBounds.height, false);
                        allCollisionBlocks.add(ceilingBlock);

                        // ۲. ساخت دیوار نامرئی برای سمت چپ محیط نبرد (ضخامت ۲۰ پیکسل)
                        SolidBlock leftWall = new SolidBlock(arenaTriggerBounds.x - 20, arenaTriggerBounds.y, 20, arenaTriggerBounds.height, false);
                        allCollisionBlocks.add(leftWall);

                        // ۳. ساخت دیوار نامرئی برای سمت راست محیط نبرد
                        SolidBlock rightWall = new SolidBlock(arenaTriggerBounds.x + arenaTriggerBounds.width, arenaTriggerBounds.y, 20, arenaTriggerBounds.height, false);
                        allCollisionBlocks.add(rightWall);

                        System.out.println("Arena Locked! The doors are closed.");
                    }
                }

                if (isArenaLocked && ceilingGateBounds != null) {
                    if (!combatController.isHeroInvincible() && hero.bounds.overlaps(ceilingGateBounds)) {
                        hero.currentHealth -= 1;
                        combatController.setHeroInvincible(true);
                        hero.velocity.y = -300f;
                    }
                }

                if (zote != null) {
                    zoteController.update(delta, zote, hero, allCollisionBlocks, combatController, zoteTalkSound);
                    combatController.handleZoteCombat(zote);
                }

                if (falseKnight != null) {
                    fkController.update(delta, falseKnight, hero);
                    combatController.handleFalseKnightCombat(falseKnight, fkController);

                    if (isArenaLocked && arenaTriggerBounds != null) {
                        float minX = arenaTriggerBounds.x;
                        float maxX = arenaTriggerBounds.x + arenaTriggerBounds.width - falseKnight.bounds.width;
                        if (falseKnight.position.x < minX) falseKnight.position.x = minX;
                        else if (falseKnight.position.x > maxX) falseKnight.position.x = maxX;
                        falseKnight.bounds.x = falseKnight.position.x;
                    }

                    if (falseKnight.currentHp <= 0) {
                        falseKnight.currentState = FalseKnightModel.State.DEAD;
                    }
                }

                if (falseKnight != null && falseKnight.triggerCameraShake) {
                    camera.position.set(hero.position.x + MathUtils.random(-8f, 8f), hero.position.y + MathUtils.random(-8f, 8f), 0);
                } else {
                    camera.position.set(hero.position.x, hero.position.y, 0);
                }
                camera.update();
            }

            mapRenderer.setView(camera);
            mapRenderer.render();

            batch.setProjectionMatrix(camera.combined);
            batch.begin();
// رسم جادوها
            for (VengefulSpiritModel vs : vengefulSpirits) {
                if (vsAnim != null) {
                    TextureRegion frame = vsAnim.getKeyFrame(vs.stateTime, true);
                    boolean shouldFlip = !vs.facingRight;
                    if (frame.isFlipX() != shouldFlip) frame.flip(true, false);
                    batch.draw(frame, vs.x, vs.y, vs.bounds.width, vs.bounds.height);
                }
            }
            for (HowlingWraithsModel hw : howlingWraiths) {
                if (hwAnim != null) {
                    TextureRegion frame = hwAnim.getKeyFrame(hw.stateTime, false);
                    batch.draw(frame, hw.x, hw.y, hw.bounds.width, hw.bounds.height);
                }
            }

            for (HuskHornheadModel h : hornheads) {
                TextureRegion frame = null;
                switch (h.currentState) {
                    case WALKING:
                        frame = hhWalkAnim.getKeyFrame(h.stateTime, true);
                        break;
                    case RESTING:
                        frame = hhIdleAnim.getKeyFrame(h.stateTime, true);
                        break;
                    case TURNING:
                        frame = hhTurnAnim.getKeyFrame(h.stateTime, false);
                        break; // 🌟 رسم چرخش
                    case CHARGING:
                        frame = hhLungeAnim.getKeyFrame(h.stateTime, true);
                        break;
                    case DEAD:
                        frame = hhDeathAnim.getKeyFrame(h.stateTime, false);
                        break;
                }
                if (frame != null) {
                    boolean shouldFlip = !h.facingLeft;
                    if (frame.isFlipX() != shouldFlip) frame.flip(true, false);
                    batch.draw(frame, h.position.x, h.position.y, 60, 60);
                }
            }

            for (MosquitoModel m : mosquitos) {
                TextureRegion frame = null;
                switch (m.currentState) {
                    case IDLE:
                        frame = mosqFlyAnim.getKeyFrame(m.stateTime, true);
                        break;
                    case TURNING:
                        frame = mosqTurnAnim.getKeyFrame(m.stateTime, false);
                        break; // 🌟 رسم چرخش
                    case ANTICIPATE:
                        frame = mosqAnticipateAnim.getKeyFrame(m.stateTime, true);
                        break;
                    case ATTACKING:
                        frame = mosqAttackAnim.getKeyFrame(m.stateTime, true);
                        break;
                    case DYING:
                        frame = mosqDyingAnim.getKeyFrame(m.stateTime, true);
                        break;
                    case DEAD:
                        frame = mosqDeadAnim.getKeyFrame(m.stateTime, false);
                        break;
                }
                if (frame != null) {

                    boolean shouldFlip = !m.facingLeft;
                    if (frame.isFlipX() != shouldFlip) frame.flip(true, false);
                    batch.draw(frame, m.position.x, m.position.y, 32, 32);
                }
            }

            for (CrystalGuardianModel cg : guardians) {
                TextureRegion cgFrame = null;
                switch (cg.currentState) {
                    case IDLE:
                        cgFrame = cgIdleAnim.getKeyFrame(cg.stateTime, true);
                        break;
                    case SHOOTING:
                        cgFrame = cgShootAnim.getKeyFrame(cg.stateTime, false);
                        break;
                    case ENRAGED:
                        cgFrame = cgRunAnim.getKeyFrame(cg.stateTime, true);
                        break;
                    case DEAD:
                        cgFrame = cgDeathAnim.getKeyFrame(cg.stateTime, false);
                        break;
                }
                if (cgFrame != null) {
                    boolean shouldFlip = !cg.facingLeft;
                    if (cgFrame.isFlipX() != shouldFlip) cgFrame.flip(true, false);
                    batch.draw(cgFrame, cg.position.x, cg.position.y, 75, 75);
                }
                if (cg.isLaserActive && laserBeamRegion != null) {

                    boolean shouldFlipLaser = cg.facingLeft;
                    if (laserBeamRegion.isFlipX() != shouldFlipLaser) {
                        laserBeamRegion.flip(true, false);
                    }


                    batch.draw(laserBeamRegion, cg.laserBounds.x, cg.laserBounds.y, cg.laserBounds.width, cg.laserBounds.height);
                }
            }

            if (zote != null) {
                TextureRegion zoteFrame = null;
                switch (zote.currentState) {
                    case IDLE:
                        zoteFrame = zoteIdleAnim.getKeyFrame(zote.stateTime, true);
                        break;
                    case TALKING:
                        zoteFrame = zoteTalkAnim.getKeyFrame(zote.stateTime, true);
                        break;
                    case FALLING:
                        zoteFrame = zoteFallAnim.getKeyFrame(zote.stateTime, false);
                        break;
                    case GET_UP:
                        zoteFrame = zoteGetUpAnim.getKeyFrame(zote.stateTime, false);
                        break;
                    case TURN:
                        zoteFrame = zoteTurnAnim.getKeyFrame(zote.stateTime, false);
                        break;
                    case ATTACK:
                        zoteFrame = zoteAttackAnim.getKeyFrame(zote.stateTime, true);
                        break;
                    default:
                        zoteFrame = zoteIdleAnim.getKeyFrame(zote.stateTime, true);
                        break;
                }
                if (zoteFrame != null) {
                    boolean shouldFlip = !zote.facingLeft;
                    if (zoteFrame.isFlipX() != shouldFlip) zoteFrame.flip(true, false);
                    batch.draw(zoteFrame, zote.position.x, zote.position.y, 40, 50);
                }

                if (zote.currentState != ZoteModel.State.ATTACK) {
                    float distanceToHero = Math.abs(hero.position.x - zote.position.x);
                    boolean isNearHero = distanceToHero < 60f && Math.abs(hero.position.y - zote.position.y) < 50f;

                    if (isNearHero && !zote.showDialogue) {
                        font.draw(batch, "[ Press E ]", zote.position.x - 10, zote.position.y + 70);
                    }

                    if (zote.showDialogue) {
                        String text = "";
                        if (zote.dialogueIndex == 0) text = "I am Zote the Mighty!";
                        else if (zote.dialogueIndex == 1) text = "A knight? Hmph. Pathetic.";
                        else if (zote.dialogueIndex == 2) text = "Leave me be, I have important thoughts.";

                        font.draw(batch, text, zote.position.x - 30, zote.position.y + 80);
                        font.draw(batch, "[ENTER]", zote.position.x, zote.position.y + 60);
                    }
                }
            }

            for (CrystalCrawlerModel crawler : crystalCrawlers) {
                TextureRegion frame = null;
                switch (crawler.currentState) {
                    case WALKING:
                        frame = crawlerWalkAnim.getKeyFrame(crawler.stateTime, true);
                        break;
                    case DYING:
                        frame = crawlerDeathAirAnim.getKeyFrame(crawler.stateTime, false);
                        break;
                    case DEAD:
                        frame = crawlerDeathLandAnim.getKeyFrame(crawler.stateTime, false);
                        break;
                }
                if (frame != null) {
                    boolean shouldFlip = !crawler.facingLeft;
                    if (frame.isFlipX() != shouldFlip) frame.flip(true, false);
                    batch.draw(frame, crawler.position.x, crawler.position.y, 40, 25);
                }
            }

            TextureRegion currentHeroFrame = null;
            switch (hero.currentAnimation) {
                case HOLLOW_KNIGHT_ATTACK:
                    currentHeroFrame = (heroAttackAnim != null) ? heroAttackAnim.getKeyFrame(hero.stateTime, false) : null;
                    break;
                case HOLLOW_KNIGHT_DASH:
                    currentHeroFrame = (heroDashAnim != null) ? heroDashAnim.getKeyFrame(hero.stateTime, false) : null;
                    break;
                case HOLLOW_KNIGHT_DOUBLE_JUMP:
                    currentHeroFrame = (heroDoubleJumpAnim != null) ? heroDoubleJumpAnim.getKeyFrame(hero.stateTime, false) : null;
                    break;
                case HOLLOW_KNIGHT_JUMP:
                    currentHeroFrame = (heroJumpAnim != null) ? heroJumpAnim.getKeyFrame(hero.stateTime, false) : null;
                    break;
                case HOLLOW_KNIGHT_WALK:
                    currentHeroFrame = (heroWalkAnim != null) ? heroWalkAnim.getKeyFrame(hero.stateTime, true) : null;
                    break;
                case HOLLOW_KNIGHT_IDLE:
                default:
                    currentHeroFrame = (heroIdleAnim != null) ? heroIdleAnim.getKeyFrame(hero.stateTime, true) : null;
                    break;
            }

            if (currentHeroFrame != null) {
                boolean shouldFlip = hero.facingRight;
                if (currentHeroFrame.isFlipX() != shouldFlip) currentHeroFrame.flip(true, false);
                batch.draw(currentHeroFrame, hero.position.x - 10, hero.position.y, 50f, 50f);
            }

            if (falseKnight != null) {
                TextureRegion fkFrame = null;
                switch (falseKnight.currentState) {
                    case IDLE:
                        fkFrame = fkIdleAnim.getKeyFrame(falseKnight.stateTime, true);
                        break;
                    case MACE_SLAM:
                        fkFrame = fkMaceSlamAnim.getKeyFrame(falseKnight.stateTime, false);
                        break;
                    case CHARGE_RUN:
                        fkFrame = fkChargeRunAnim.getKeyFrame(falseKnight.stateTime, true);
                        break;
                    case OFFENSIVE_LEAP:
                    case DEFENSIVE_LEAP:
                    case JUMP_ATTACK:
                        fkFrame = fkJumpAnim.getKeyFrame(falseKnight.stateTime, false);
                        break;
                    case POWER_SLAM:
                        fkFrame = fkPowerSlamAnim.getKeyFrame(falseKnight.stateTime, false);
                        break;
                    case STUNNED:
                        fkFrame = fkStunnedAnim.getKeyFrame(falseKnight.stateTime, true);
                        break;
                    case STUN_RECOVER:
                        fkFrame = fkStunRecoverAnim.getKeyFrame(falseKnight.stateTime, false);
                        break;
                    case DEAD:
                        fkFrame = fkDeathLandAnim.getKeyFrame(falseKnight.stateTime, false);
                        break;
                }
                if (fkFrame != null) {
                    // 🌟 تغییر از facingLeft به علامت منفی/معکوس آن برای تنظیم صحیح جهت صورت به سمت پلیر
                    boolean shouldFlip = !falseKnight.facingLeft;
                    if (fkFrame.isFlipX() != shouldFlip) fkFrame.flip(true, false);
                    batch.draw(fkFrame, falseKnight.position.x, falseKnight.position.y, 180f, 180f);
                }
            }
            batch.end();
            shapeRenderer = new com.badlogic.gdx.graphics.glutils.ShapeRenderer();

            shapeRenderer.setProjectionMatrix(camera.combined);
            shapeRenderer.begin(ShapeRenderer.ShapeType.Line);
            shapeRenderer.setColor(com.badlogic.gdx.graphics.Color.RED);

// رسم مستطیل برخورد هیرو
            shapeRenderer.rect(hero.bounds.x, hero.bounds.y, hero.bounds.width, hero.bounds.height);

// رسم مستطیل برخورد باس
            if (falseKnight != null) {
                shapeRenderer.setColor(com.badlogic.gdx.graphics.Color.BLUE);
                shapeRenderer.rect(falseKnight.bounds.x, falseKnight.bounds.y, falseKnight.bounds.width, falseKnight.bounds.height);
            }
            shapeRenderer.end();

            // ۳. رسم نهایی رابط کاربری (HUD)

            if (!isPaused) {
                batch.setProjectionMatrix(hudCamera.combined);
                batch.begin();

                batch.draw(hudContainer, 10f, 185f, hudContainer.getWidth() * 0.35f, hudContainer.getHeight() * 0.35f);

                // ۲. رسم عدد روح
                font.getData().setScale(0.9f);
                font.draw(batch, String.valueOf(hero.soul), 45f, 215f);
                font.getData().setScale(1.0f);

                float startMaskX = 90f;
                float maskY = 200f;
                float maskSpacing = 28f;

                for (int i = 0; i < hero.maxHealth; i++) {
                    if (i < hero.currentHealth) {
                        // ماسک پر (سفید)
                        batch.draw(fullMaskRegion, startMaskX + (i * maskSpacing), maskY, 22f, 28f);
                    } else {
                        // ماسک خالی (تیره)
                        batch.draw(emptyMaskRegion, startMaskX + (i * maskSpacing), maskY, 22f, 28f);
                    }
                }

                batch.end();
            }
            uiStage.act(delta);
            uiStage.draw();
        }

    @Override
    public void resize(int width, int height) {
        viewport.update(width, height);
        if (uiStage != null) uiStage.getViewport().update(width, height, true);
    }
    private void showEndGameScreen(boolean isVictory) {

        if (winMenuTable == null) {
            winMenuTable = new Table();
            winMenuTable.setFillParent(true);
            winMenuTable.center();
            uiStage.addActor(winMenuTable);
        }
        winMenuTable.clear();

        com.badlogic.gdx.graphics.Pixmap pixmap = new com.badlogic.gdx.graphics.Pixmap(1, 1, com.badlogic.gdx.graphics.Pixmap.Format.RGBA8888);
        pixmap.setColor(new com.badlogic.gdx.graphics.Color(0, 0, 0, 0.85f)); // مشکی با ۸۵٪ وضوح
        pixmap.fill();
        winMenuTable.setBackground(new com.badlogic.gdx.scenes.scene2d.utils.TextureRegionDrawable(new com.badlogic.gdx.graphics.Texture(pixmap)));
        pixmap.dispose();


        com.badlogic.gdx.scenes.scene2d.ui.Label.LabelStyle titleStyle =
            new com.badlogic.gdx.scenes.scene2d.ui.Label.LabelStyle(font, isVictory ? com.badlogic.gdx.graphics.Color.GREEN : com.badlogic.gdx.graphics.Color.RED);
        com.badlogic.gdx.scenes.scene2d.ui.Label.LabelStyle textStyle =
            new com.badlogic.gdx.scenes.scene2d.ui.Label.LabelStyle(font, com.badlogic.gdx.graphics.Color.WHITE);

        String titleText = isVictory ? "VICTORY! - BOSS DEFEATED" : "GAME OVER - YOU DIED";

        com.badlogic.gdx.scenes.scene2d.ui.Label titleLabel = new com.badlogic.gdx.scenes.scene2d.ui.Label(titleText, titleStyle);
        com.badlogic.gdx.scenes.scene2d.ui.Label deathLabel = new com.badlogic.gdx.scenes.scene2d.ui.Label("Total Deaths: " + deathCount + " (5 Marks)", textStyle);
        com.badlogic.gdx.scenes.scene2d.ui.Label killsLabel = new com.badlogic.gdx.scenes.scene2d.ui.Label("Enemies Killed: " + enemiesKilledCount + " (5 Marks)", textStyle);

        int minutes = (int) (totalGameTime / 60);
        int seconds = (int) (totalGameTime % 60);
        com.badlogic.gdx.scenes.scene2d.ui.Label timeLabel = new com.badlogic.gdx.scenes.scene2d.ui.Label(String.format("Total Time: %02d:%02d (5 Marks)", minutes, seconds), textStyle);

        TextButton restartBtn = new TextButton("Restart", skin);
        restartBtn.addListener(new ClickListener() {
            @Override
            public void clicked(InputEvent event, float x, float y) {
                com.badlogic.gdx.Game game = (com.badlogic.gdx.Game) Gdx.app.getApplicationListener();
                game.setScreen(new GamePlayScreen(mapPath)); // ریلود کردن صفحه بازی
            }
        });

        TextButton mainMenuBtn = new TextButton("Main Menu", skin);
        mainMenuBtn.addListener(new ClickListener() {
            @Override
            public void clicked(InputEvent event, float x, float y) {
                com.badlogic.gdx.Game game = (com.badlogic.gdx.Game) Gdx.app.getApplicationListener();
                // game.setScreen(new MainMenuScreen()); // نام کلاس منوی اصلی خودت رو اینجا بذار
            }
        });

        // چیدمان المان‌ها در وسط صفحه
        winMenuTable.add(titleLabel).pad(20).row();
        winMenuTable.add(deathLabel).pad(10).row();
        winMenuTable.add(killsLabel).pad(10).row();
        winMenuTable.add(timeLabel).pad(10).row();
        winMenuTable.add(restartBtn).width(200).height(50).pad(10).padTop(30).row();
        winMenuTable.add(mainMenuBtn).width(200).height(50).pad(10).row();

        winMenuTable.setVisible(true);
        winMenuTable.toFront();

        if (hudTable != null) hudTable.setVisible(false);
    }
    @Override
    public void hide() {
        dispose();
    }

    @Override
    public void dispose() {
        if (map != null) map.dispose();
        if (mapRenderer != null) mapRenderer.dispose();
        if (batch != null) batch.dispose();
        if (spikesTexture != null) spikesTexture.dispose();
        if (uiStage != null) uiStage.dispose();
        if (font != null) font.dispose();
    }
}
