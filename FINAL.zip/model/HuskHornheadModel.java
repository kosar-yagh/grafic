package com.Knight.model;

import com.badlogic.gdx.math.Rectangle;
import com.badlogic.gdx.math.Vector2;

public class HuskHornheadModel {
    public enum State { WALKING, RESTING, CHARGING, TURNING,DEAD }

    public State currentState;
    public Vector2 position;
    public Vector2 velocity;
    public Rectangle bounds;
    public Rectangle visionZone;

    public float stateTime;
    public boolean facingLeft;
    public float damageCooldown = 0f;

    public int hp = 30;

    public HuskHornheadModel(float x, float y, Rectangle visionZone) {
        this.position = new Vector2(x, y);
        this.velocity = new Vector2(0, 0);
        this.bounds = new Rectangle(x, y, 40, 50);
        this.visionZone = visionZone;

        this.currentState = State.WALKING;
        this.stateTime = 0f;
        this.facingLeft = true;
    }
}
