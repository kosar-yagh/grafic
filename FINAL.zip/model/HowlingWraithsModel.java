package com.Knight.model;
import com.badlogic.gdx.math.Rectangle;

public class HowlingWraithsModel {
    public float x, y;
    public Rectangle bounds;
    public boolean active = true;
    public float stateTime = 0;
    public int ticks = 0;
    public float tickTimer = 0.15f;

    public HowlingWraithsModel(float x, float y) {
        this.x = x - 30;
        this.y = y + 40;
        this.bounds = new Rectangle(this.x, this.y, 110, 160);  }

    public void update(float delta) {
        stateTime += delta;
        tickTimer += delta;
        if (stateTime > 0.6f) {
            active = false;
        }
    }
}
