package com.Knight.controller;

import com.Knight.model.ZoteModel;
import com.Knight.model.Hero;
import com.Knight.model.SolidBlock;
import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Input;
import com.badlogic.gdx.audio.Sound;
import com.badlogic.gdx.utils.Array;

public class ZoteController {
    private static final float GRAVITY = -450f;
    private static final float ATTACK_SPEED = 120f;
    private static final float INTERACT_DISTANCE = 60f;

    // متغیری برای جلوگیری از پرش چندتایی دیالوگ با یک بار فشردن Enter
    private boolean enterPressedLastFrame = false;

    public void update(float delta, ZoteModel zote, Hero hero, Array<SolidBlock> blocks, CombatController combatController, Sound talkSound) {
        zote.stateTime += delta;

        if (zote.damageCooldown > 0) zote.damageCooldown -= delta;



        float distanceForAttack = Math.abs(hero.position.x - zote.position.x);
        boolean isInSwordRange = distanceForAttack < 70f && Math.abs(hero.position.y - zote.position.y) < 50f;


        if (isInSwordRange && Gdx.input.isKeyJustPressed(Input.Keys.X)) {
            if (zote.currentState != ZoteModel.State.ATTACK) {
                zote.currentState = ZoteModel.State.ATTACK;
                zote.stateTime = 0;
                zote.showDialogue = false; // بستن دیالوگ در صورت حمله
                zote.facingLeft = hero.position.x < zote.position.x;
            }
        }




        float distanceToHero = Math.abs(hero.position.x - zote.position.x);
        boolean isNearHero = distanceToHero < INTERACT_DISTANCE && Math.abs(hero.position.y - zote.position.y) < 50;

        // شروع دیالوگ با کلید E یا فلش بالا
        if (isNearHero && zote.currentState != ZoteModel.State.ATTACK) {
            if (Gdx.input.isKeyJustPressed(Input.Keys.E) || Gdx.input.isKeyJustPressed(Input.Keys.UP)) {
                if (!zote.showDialogue) {
                    zote.currentState = ZoteModel.State.TALKING;
                    zote.showDialogue = true;
                    zote.dialogueIndex = 0; // شروع از خط اول
                    zote.facingLeft = hero.position.x < zote.position.x;
                    System.out.println("🔊 Zote Voice is Playing NOW!");
                    if (talkSound != null) talkSound.play(4.0f);
                }
            }
        } else if (!isNearHero && zote.showDialogue) {
            // دور شدن بازیکن = بسته شدن خودکار دیالوگ
            zote.showDialogue = false;
            zote.currentState = ZoteModel.State.IDLE;
        }


        if (zote.showDialogue) {
            hero.velocity.x = 0;

            boolean enterJustPressed = Gdx.input.isKeyJustPressed(Input.Keys.ENTER);
            if (enterJustPressed && !enterPressedLastFrame) {
                zote.dialogueIndex++; // رفتن به خط بعدی

                if (zote.dialogueIndex > 2) {
                    // پایان دیالوگ پس از حداقل ۳ خط
                    zote.showDialogue = false;
                    zote.currentState = ZoteModel.State.IDLE;
                } else {
                    if (talkSound != null) talkSound.play(0.7f); // پخش صدای متفاوت/مجدد برای خط جدید
                }
            }
            enterPressedLastFrame = enterJustPressed;
        } else {
            enterPressedLastFrame = false;
        }


        // ۳. ماشین حالت زوت

        switch (zote.currentState) {
            case FALLING:
                if (zote.velocity.y == 0 && zote.stateTime > 0.3f) {
                    zote.currentState = ZoteModel.State.GET_UP;
                    zote.stateTime = 0;
                    zote.velocity.x = 0;
                }
                break;
            case GET_UP:
                if (zote.stateTime > 0.5f) {
                    zote.currentState = ZoteModel.State.TURN;
                    zote.stateTime = 0;
                    zote.facingLeft = hero.position.x < zote.position.x;
                }
                break;
            case TURN:
                if (zote.stateTime > 0.2f) {
                    zote.currentState = ZoteModel.State.ATTACK;
                    zote.stateTime = 0;
                }
                break;
            case ATTACK:
                zote.velocity.x = zote.facingLeft ? -ATTACK_SPEED : ATTACK_SPEED;

                // برخورد با بازیکن در حالت حمله (طبق قانون: دمیج نمی‌دهد، فقط هل می‌دهد)
                if (zote.bounds.overlaps(hero.bounds) && zote.damageCooldown <= 0) {
                    // حذف شد: hero.currentHealth -= 1;
                    hero.position.x += zote.facingLeft ? -30f : 30f; // فقط یک ضربه پس‌زننده فانتزی
                    zote.damageCooldown = 1.0f;

                    zote.currentState = ZoteModel.State.IDLE;
                    zote.velocity.x = 0;
                }

                // پایان زمان عصبانیت زوت (پس از ۲ ثانیه)
                if (zote.stateTime > 2.0f) {
                    zote.currentState = ZoteModel.State.IDLE;
                    zote.velocity.x = 0;
                }
                break;
            case TALKING:
                zote.velocity.x = 0;
                break;
            default:
                if (zote.currentState != ZoteModel.State.FALLING && zote.currentState != ZoteModel.State.ATTACK) {
                    zote.velocity.x = 0;
                }
                break;
        }


        // ۴. فیزیک برخورد اصلاح شده (جلوگیری از سقوط)

        zote.velocity.y += GRAVITY * delta;

        // حرکت محور X
        zote.position.x += zote.velocity.x * delta;
        zote.bounds.x = zote.position.x;

        // حرکت محور Y
        zote.position.y += zote.velocity.y * delta;
        zote.bounds.y = zote.position.y;

        for (SolidBlock block : blocks) {
            if (zote.bounds.overlaps(block.bounds)) {
                if (zote.velocity.y < 0) { // برخورد با زمین در حال سقوط
                    zote.position.y = block.bounds.y + block.bounds.height;
                    zote.bounds.y = zote.position.y;
                    zote.velocity.y = 0;
                }
            }
        }
    }
}
