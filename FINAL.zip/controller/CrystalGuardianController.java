package com.Knight.controller;

import com.Knight.model.Hero;
import com.Knight.model.CrystalGuardianModel;
import com.Knight.model.SolidBlock;
import com.badlogic.gdx.utils.Array;

public class CrystalGuardianController {
    private static final float CHARGE_SPEED = 260f;
    private static final float ENRAGED_DURATION = 3.0f;
    private static final float SHOOT_DURATION = 0.8f;

    public void update(float delta, CrystalGuardianModel enemy, Hero hero, Array<SolidBlock> blocks, CombatController combatController) {
        enemy.stateTime += delta;

        if (enemy.damageCooldown > 0) enemy.damageCooldown -= delta;

        // 🌟 بررسی مرگ
        if (enemy.hp <= 0 && enemy.currentState != CrystalGuardianModel.State.DEAD) {
            enemy.currentState = CrystalGuardianModel.State.DEAD;
            enemy.isLaserActive = false;
            enemy.stateTime = 0;
        }

        // اعمال جاذبه زمین (حتی برای جسد)
        enemy.velocity.y -= 450 * delta;

        if (enemy.currentState != CrystalGuardianModel.State.DEAD) {
            if (enemy.facingLeft) {
                enemy.visionZone.setX(enemy.position.x - enemy.visionZone.width);
            } else {
                enemy.visionZone.setX(enemy.position.x + enemy.bounds.width);
            }
            enemy.visionZone.setY(enemy.position.y);

            switch (enemy.currentState) {
                case IDLE:
                    enemy.velocity.x = 0;
                    enemy.isLaserActive = false;
                    if (enemy.visionZone.overlaps(hero.bounds)) {
                        enemy.currentState = CrystalGuardianModel.State.SHOOTING;
                        enemy.stateTime = 0;
                    }
                    break;

                case SHOOTING:
                    enemy.velocity.x = 0;
                    if (enemy.stateTime > 0.2f && enemy.stateTime < SHOOT_DURATION) {
                        enemy.isLaserActive = true;
                        float laserLength = 500f;

                        if (enemy.facingLeft) {
                            enemy.laserBounds.set(enemy.position.x - laserLength, enemy.position.y + 25, laserLength, 15);
                        } else {
                            enemy.laserBounds.set(enemy.position.x + enemy.bounds.width, enemy.position.y + 25, laserLength, 15);
                        }

                        if (enemy.laserBounds.overlaps(hero.bounds) && enemy.damageCooldown <= 0) {
                            if (combatController != null && !combatController.isHeroInvincible()) {
                                hero.currentHealth -= 1;
                                enemy.damageCooldown = 1.2f;
                                hero.position.x += enemy.facingLeft ? -25f : 25f;
                            }
                        }
                    } else {
                        enemy.isLaserActive = false;
                    }

                    if (enemy.stateTime >= SHOOT_DURATION) {
                        enemy.currentState = CrystalGuardianModel.State.ENRAGED;
                        enemy.stateTime = 0;
                        enemy.enragedTimer = 0;
                        enemy.isLaserActive = false;
                        enemy.facingLeft = (hero.position.x < enemy.position.x);
                    }
                    break;

                case ENRAGED:
                    enemy.enragedTimer += delta;
                    enemy.velocity.x = enemy.facingLeft ? -CHARGE_SPEED : CHARGE_SPEED;

                    if (enemy.bounds.overlaps(hero.bounds) && enemy.damageCooldown <= 0) {
                        if (combatController != null && !combatController.isHeroInvincible()) {
                            hero.currentHealth -= 1;
                            enemy.damageCooldown = 1.2f;
                            hero.position.x += enemy.facingLeft ? -30f : 30f;
                        }
                    }

                    if (enemy.enragedTimer >= ENRAGED_DURATION) {
                        enemy.currentState = CrystalGuardianModel.State.IDLE;
                        enemy.stateTime = 0;
                    }
                    break;
            }
        } else {
            enemy.velocity.x = 0; // جسد حرکت نمی‌کند
        }

        float oldX = enemy.position.x;
        enemy.position.x += enemy.velocity.x * delta;
        enemy.bounds.setPosition(enemy.position.x, enemy.position.y);

        for (SolidBlock block : blocks) {
            if (enemy.bounds.overlaps(block.bounds)) {
                enemy.position.x = oldX;
                enemy.bounds.setPosition(enemy.position.x, enemy.position.y);
                if (enemy.currentState == CrystalGuardianModel.State.ENRAGED) {
                    enemy.facingLeft = !enemy.facingLeft;
                }
                break;
            }
        }

        float oldY = enemy.position.y;
        enemy.position.y += enemy.velocity.y * delta;
        enemy.bounds.setPosition(enemy.position.x, enemy.position.y);

        for (SolidBlock block : blocks) {
            if (enemy.bounds.overlaps(block.bounds)) {
                if (enemy.velocity.y <= 0) {
                    enemy.velocity.y = 0;
                    enemy.position.y = block.bounds.y + block.bounds.height;
                } else {
                    enemy.velocity.y = 0;
                    enemy.position.y = block.bounds.y - enemy.bounds.height;
                }
                enemy.bounds.setPosition(enemy.position.x, enemy.position.y);
                break;
            }
        }}
}
